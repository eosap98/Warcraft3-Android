package com.etheller.warsmash.android;

import java.util.function.BooleanSupplier;

import android.view.Choreographer;

import com.etheller.warsmash.util.FrameCadence;

/** Requests GL frames on display callbacks; stops completely while paused or when the launcher is still. */
final class AndroidFramePacer implements Choreographer.FrameCallback {
	private final Choreographer choreographer = Choreographer.getInstance();
	private final FrameCadence cadence;
	private final Runnable render;
	private final BooleanSupplier needed;
	private boolean running;
	private boolean scheduled;

	AndroidFramePacer(final int fps, final Runnable render, final BooleanSupplier needed) {
		this.cadence = new FrameCadence(fps);
		this.render = render;
		this.needed = needed;
	}

	void start() {
		this.running = true;
		this.cadence.reset();
		wake();
	}

	void wake() {
		if (this.running && !this.scheduled) {
			this.scheduled = true;
			this.choreographer.postFrameCallback(this);
		}
	}

	void stop() {
		this.running = false;
		this.scheduled = false;
		this.choreographer.removeFrameCallback(this);
		this.cadence.reset();
	}

	@Override
	public void doFrame(final long frameTimeNanos) {
		this.scheduled = false;
		if (!this.running || !this.needed.getAsBoolean()) {
			this.cadence.reset();
			return;
		}
		if (this.cadence.shouldRender(frameTimeNanos)) {
			this.render.run();
		}
		wake();
	}
}
