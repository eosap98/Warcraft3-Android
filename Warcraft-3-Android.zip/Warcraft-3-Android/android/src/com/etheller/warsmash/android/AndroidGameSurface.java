package com.etheller.warsmash.android;

import android.annotation.SuppressLint;
import android.graphics.Matrix;
import android.util.Log;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.SurfaceView;

import com.badlogic.gdx.backends.android.AndroidGraphics;
import com.badlogic.gdx.backends.android.AndroidInput;
import com.etheller.warsmash.input.touch.InputViewport;
import com.etheller.warsmash.util.RenderResolution;

/** A smaller GL buffer stretched by Android's compositor; native launcher and mod controls stay full resolution. */
final class AndroidGameSurface {
	private final SurfaceView view;
	private final AndroidInput input;
	private final AndroidPointerSource pointers;
	private final int shortEdge;
	private final Matrix inputMatrix = new Matrix();
	private int bufferWidth;
	private int bufferHeight;

	// This listener forwards game gestures to libGDX. Native buttons retain their own click listeners.
	@SuppressLint("ClickableViewAccessibility")
	AndroidGameSurface(final AndroidGraphics graphics, final AndroidInput input, final AndroidPointerSource pointers,
			final int shortEdge) {
		this.view = (SurfaceView) graphics.getView();
		this.input = input;
		this.pointers = pointers;
		this.shortEdge = shortEdge;
		InputViewport.setInputSize(0, 0);
		if (pointers != null) {
			pointers.setView(this.view);
		}
		// Finger/pen events are routed by the Activity. Mouse input and TouchControls=Off still go
		// through libGDX, whose default input assumes that view and GL pixels have the same size.
		this.view.setOnTouchListener((view, event) -> dispatchNative(event, false));
		this.view.setOnGenericMotionListener((view, event) -> dispatchNative(event, true));
		this.view.addOnLayoutChangeListener((view, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
			if (((right - left) != (oldRight - oldLeft)) || ((bottom - top) != (oldBottom - oldTop))) {
				resize(right - left, bottom - top);
			}
		});
		resize(this.view.getWidth(), this.view.getHeight());
	}

	private void resize(final int width, final int height) {
		if ((width <= 0) || (height <= 0)) {
			return;
		}
		if ((this.bufferWidth != 0) && (this.pointers != null)) {
			this.pointers.cancel();
		}
		InputViewport.setInputSize(width, height);
		final RenderResolution size = RenderResolution.fit(width, height, this.shortEdge);
		if ((size.width != this.bufferWidth) || (size.height != this.bufferHeight)) {
			this.bufferWidth = size.width;
			this.bufferHeight = size.height;
			this.view.getHolder().setFixedSize(size.width, size.height);
			Log.i("Warsmash", "Game surface: " + width + "x" + height + " -> " + size.width + "x" + size.height);
		}
	}

	private boolean dispatchNative(final MotionEvent event, final boolean generic) {
		final float scaleX = InputViewport.scaleX();
		final float scaleY = InputViewport.scaleY();
		if (((scaleX == 1) && (scaleY == 1))
				|| ((event.getSource() & InputDevice.SOURCE_CLASS_POINTER) == 0)) {
			return nativeInput(event, generic);
		}
		final MotionEvent scaled = MotionEvent.obtain(event);
		try {
			this.inputMatrix.setScale(scaleX, scaleY);
			scaled.transform(this.inputMatrix);
			return nativeInput(scaled, generic);
		}
		finally {
			scaled.recycle();
		}
	}

	private boolean nativeInput(final MotionEvent event, final boolean generic) {
		return generic ? this.input.onGenericMotion(this.view, event) : this.input.onTouch(this.view, event);
	}
}
