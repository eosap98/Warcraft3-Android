package com.etheller.warsmash.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.etheller.warsmash.launcher.LauncherKeys;

/** A small native overlay: transparent outside its controls, with no per-frame drawing or polling. */
final class InGameModMenu extends FrameLayout {
	interface Actions {
		void addResources(int gold, int lumber);
	}

	private final SharedPreferences preferences;
	private final FrameLayout dot;
	private final ScrollView panel;
	private final int[] screenPosition = new int[2];
	private boolean available;
	private boolean hidden;
	private float positionX;
	private float positionY;
	private float panelPositionX;
	private float panelPositionY;
	private boolean panelPositioned;

	InGameModMenu(final Context context, final Actions actions) {
		super(context);
		this.preferences = context.getSharedPreferences(LauncherKeys.PREFERENCES, Context.MODE_PRIVATE);
		this.hidden = this.preferences.getBoolean("mod_menu_hidden", false);
		this.positionX = this.preferences.getFloat("mod_menu_x", 0.04f);
		this.positionY = this.preferences.getFloat("mod_menu_y", 0.22f);
		this.panelPositionX = this.preferences.getFloat("mod_panel_x", 0);
		this.panelPositionY = this.preferences.getFloat("mod_panel_y", 0);
		this.panelPositioned = this.preferences.getBoolean("mod_panel_positioned", false);
		setClipChildren(false);
		setVisibility(GONE);

		// Only the 6 dp dot is drawn. The surrounding 48 dp touch target has no background or shadow.
		this.dot = new FrameLayout(context);
		final View point = new View(context);
		final GradientDrawable circle = new GradientDrawable();
		circle.setShape(GradientDrawable.OVAL);
		circle.setColor(Color.rgb(255, 219, 139));
		point.setBackground(circle);
		this.dot.addView(point, new LayoutParams(dp(6), dp(6), Gravity.CENTER));
		this.dot.setContentDescription(context.getString(R.string.mod_dot_description));
		this.dot.setFocusable(true);
		addView(this.dot, new LayoutParams(dp(48), dp(48)));

		this.panel = new ScrollView(context);
		this.panel.setFillViewport(false);
		this.panel.setBackground(background(0xBC101923, dp(12)));
		this.panel.setElevation(dp(4));
		this.panel.setVisibility(GONE);
		this.panel.setOverScrollMode(OVER_SCROLL_NEVER);
		final LinearLayout rows = new LinearLayout(context);
		rows.setOrientation(LinearLayout.VERTICAL);
		rows.setPadding(dp(12), dp(6), dp(12), dp(10));
		this.panel.addView(rows, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.WRAP_CONTENT));
		addView(this.panel, new LayoutParams(dp(250), ViewGroup.LayoutParams.WRAP_CONTENT));
		this.panel.addOnLayoutChangeListener((view, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
			if (((right - left) != (oldRight - oldLeft)) || ((bottom - top) != (oldBottom - oldTop))) {
				placePanel();
			}
		});

		final TextView title = label(context.getString(R.string.mod_title), 16, Color.rgb(255, 219, 139));
		title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
		title.setGravity(Gravity.CENTER_VERTICAL);
		title.setContentDescription(context.getString(R.string.mod_drag_description));
		rows.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
		addButton(rows, R.string.mod_gold, () -> actions.addResources(1000, 0));
		addButton(rows, R.string.mod_lumber, () -> actions.addResources(0, 1000));
		addButton(rows, R.string.mod_both, () -> actions.addResources(10000, 10000));
		final LinearLayout footer = new LinearLayout(context);
		footer.setOrientation(LinearLayout.HORIZONTAL);
		rows.addView(footer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
		addFooterButton(footer, R.string.mod_close, () -> this.panel.setVisibility(GONE));
		addFooterButton(footer, R.string.mod_hide, this::hideIcon);

		this.dot.setOnClickListener(view -> {
			this.panel.setVisibility(this.panel.getVisibility() == VISIBLE ? GONE : VISIBLE);
			post(this::placePanel);
		});
		makeDraggable(this.dot, this.dot);
		makeDraggable(title, this.panel);
	}

	void setAvailable(final boolean available) {
		if (this.available == available) {
			return;
		}
		this.available = available;
		if (!available) {
			this.panel.setVisibility(GONE);
		}
		setVisibility(available && !this.hidden ? VISIBLE : GONE);
	}

	boolean isHiddenInGame() {
		return this.available && this.hidden;
	}

	void revealIcon() {
		if (!this.available) {
			return;
		}
		this.hidden = false;
		this.preferences.edit().putBoolean("mod_menu_hidden", false).apply();
		setVisibility(VISIBLE);
	}

	private void hideIcon() {
		this.hidden = true;
		this.panel.setVisibility(GONE);
		setVisibility(GONE);
		this.preferences.edit().putBoolean("mod_menu_hidden", true).apply();
		Toast.makeText(getContext(), R.string.mod_restore_hint, Toast.LENGTH_LONG).show();
	}

	/** Tested at the start of a pointer stream; that whole stream then belongs to the overlay. */
	boolean containsTouch(final MotionEvent event) {
		return (getVisibility() == VISIBLE) && (hit(this.dot, event) || hit(this.panel, event));
	}

	private boolean hit(final View view, final MotionEvent event) {
		if (view.getVisibility() != VISIBLE) {
			return false;
		}
		view.getLocationOnScreen(this.screenPosition);
		final float x = event.getRawX() - this.screenPosition[0];
		final float y = event.getRawY() - this.screenPosition[1];
		return (x >= 0) && (y >= 0) && (x < view.getWidth()) && (y < view.getHeight());
	}

	private TextView label(final String text, final int size, final int color) {
		final TextView view = new TextView(getContext());
		view.setText(text);
		view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
		view.setTextColor(color);
		view.setIncludeFontPadding(false);
		return view;
	}

	private TextView button(final int label, final Runnable action) {
		final TextView view = label(getContext().getString(label), 14, Color.WHITE);
		view.setGravity(Gravity.CENTER);
		view.setPadding(dp(6), dp(4), dp(6), dp(4));
		view.setBackground(background(0x553B5262, dp(6)));
		view.setFocusable(true);
		view.setOnClickListener(clicked -> action.run());
		return view;
	}

	private void addButton(final LinearLayout rows, final int label, final Runnable action) {
		final LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
		layout.bottomMargin = dp(6);
		rows.addView(button(label, action), layout);
	}

	private void addFooterButton(final LinearLayout row, final int label, final Runnable action) {
		final LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1);
		layout.setMargins(dp(2), dp(3), dp(2), 0);
		row.addView(button(label, action), layout);
	}

	private GradientDrawable background(final int color, final int radius) {
		final GradientDrawable background = new GradientDrawable();
		background.setColor(color);
		background.setCornerRadius(radius);
		background.setStroke(dp(1), 0x669BB4C6);
		return background;
	}

	private void makeDraggable(final View handle, final View movable) {
		handle.setOnTouchListener(new OnTouchListener() {
			private float downX;
			private float downY;
			private float startX;
			private float startY;
			private boolean moved;
			private boolean tracking;
			private final int slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();

			@Override
			public boolean onTouch(final View view, final MotionEvent event) {
				if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
					this.downX = event.getRawX();
					this.downY = event.getRawY();
					this.startX = movable.getX();
					this.startY = movable.getY();
					this.moved = false;
					this.tracking = true;
					view.getParent().requestDisallowInterceptTouchEvent(true);
				}
				else if (event.getPointerCount() > 1) {
					this.tracking = false;
					this.moved = true;
				}
				else if (((event.getActionMasked() == MotionEvent.ACTION_MOVE)
						|| (event.getActionMasked() == MotionEvent.ACTION_UP)) && this.tracking) {
					final float dx = event.getRawX() - this.downX;
					final float dy = event.getRawY() - this.downY;
					this.moved |= Math.hypot(dx, dy) > this.slop;
					if (this.moved) {
						if (movable == InGameModMenu.this.dot) {
							moveDot(this.startX + dx, this.startY + dy);
						}
						else {
							movePanel(this.startX + dx, this.startY + dy);
							InGameModMenu.this.panelPositioned = true;
						}
					}
				}
				if (event.getActionMasked() == MotionEvent.ACTION_UP) {
					if (this.tracking && !this.moved) {
						view.performClick();
					}
					if (this.moved) {
						savePosition();
					}
					this.tracking = false;
					view.getParent().requestDisallowInterceptTouchEvent(false);
				}
				else if (event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
					if (this.moved) {
						savePosition();
					}
					this.tracking = false;
					view.getParent().requestDisallowInterceptTouchEvent(false);
				}
				return true;
			}
		});
	}

	@Override
	protected void onSizeChanged(final int width, final int height, final int oldWidth, final int oldHeight) {
		super.onSizeChanged(width, height, oldWidth, oldHeight);
		final ViewGroup.LayoutParams params = this.panel.getLayoutParams();
		params.width = Math.min(dp(250), Math.max(1, width));
		params.height = Math.min(dp(276), Math.max(1, height));
		this.panel.setLayoutParams(params);
		final float overhang = dotOverhang();
		moveDot(this.positionX * Math.max(0, width - dp(6)) - overhang,
				this.positionY * Math.max(0, height - dp(6)) - overhang);
		post(this::placePanel);
	}

	private float dotOverhang() {
		return (dp(48) - dp(6)) / 2f;
	}

	private void moveDot(final float x, final float y) {
		// The invisible hit area may cross an edge; the visible point can reach every corner.
		final float overhang = dotOverhang();
		this.dot.setX(clamp(x, -overhang, getWidth() - dp(48) + overhang));
		this.dot.setY(clamp(y, -overhang, getHeight() - dp(48) + overhang));
		this.positionX = (this.dot.getX() + overhang) / Math.max(1, getWidth() - dp(6));
		this.positionY = (this.dot.getY() + overhang) / Math.max(1, getHeight() - dp(6));
	}

	private void movePanel(final float x, final float y) {
		// Let the panel cross the sides and bottom too; keep a piece of its title reachable to drag it back.
		final float minX = panelMinX();
		final float maxX = Math.max(0, getWidth() - dp(64));
		final float maxY = Math.max(0, getHeight() - dp(48));
		this.panel.setX(clamp(x, minX, maxX));
		this.panel.setY(clamp(y, 0, maxY));
		this.panelPositionX = (this.panel.getX() - minX) / Math.max(1, maxX - minX);
		this.panelPositionY = this.panel.getY() / Math.max(1, maxY);
	}

	private float panelMinX() {
		return Math.min(0, Math.min(dp(64), getWidth()) - this.panel.getWidth());
	}

	private void placePanel() {
		if (this.panelPositioned) {
			final float minX = panelMinX();
			movePanel(minX + this.panelPositionX * (Math.max(0, getWidth() - dp(64)) - minX),
					this.panelPositionY * Math.max(0, getHeight() - dp(48)));
		}
		else {
			final float right = this.dot.getX() + dp(48);
			final float left = this.dot.getX() - this.panel.getWidth();
			movePanel(clamp(right + this.panel.getWidth() <= getWidth() ? right : left, 0,
					getWidth() - this.panel.getWidth()), clamp(this.dot.getY(), 0, getHeight() - this.panel.getHeight()));
		}
	}

	private void savePosition() {
		this.preferences.edit().putFloat("mod_menu_x", this.positionX).putFloat("mod_menu_y", this.positionY)
				.putFloat("mod_panel_x", this.panelPositionX).putFloat("mod_panel_y", this.panelPositionY)
				.putBoolean("mod_panel_positioned", this.panelPositioned).apply();
	}

	private static float clamp(final float value, final float low, final float high) {
		return Math.max(low, Math.min(Math.max(low, high), value));
	}

	private int dp(final float value) {
		return Math.round(value * getResources().getDisplayMetrics().density);
	}
}
