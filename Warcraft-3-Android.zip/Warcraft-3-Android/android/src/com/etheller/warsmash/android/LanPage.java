package com.etheller.warsmash.android;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.etheller.warsmash.launcher.LanMapData;
import com.etheller.warsmash.launcher.LaunchRequest;
import com.etheller.warsmash.launcher.LauncherBoard;
import com.etheller.warsmash.networking.lan.LanAddresses;
import com.etheller.warsmash.networking.lan.LanClient;
import com.etheller.warsmash.networking.lan.LanGameSetup;
import com.etheller.warsmash.networking.lan.LanLobby;
import com.etheller.warsmash.networking.lan.LanServer;
import com.etheller.warsmash.networking.lan.LanSession;
import com.etheller.warsmash.viewer5.handlers.w3x.replay.GameReplays;

/** Native Android LAN lobby. The host runs in this app; joining never needs an Internet service. */
final class LanPage extends LauncherViews {
	private final ExecutorService worker = Executors.newSingleThreadExecutor(action -> {
		final Thread thread = new Thread(action, "LAN setup");
		thread.setDaemon(true);
		return thread;
	});
	private List<GameCatalog.MapEntry> maps;
	private boolean readingMaps;
	private String selectedPath;
	private LanMapData selected;
	private LanMapData verified;
	private boolean readingMap;
	private boolean checking;
	private boolean connecting;
	private boolean handedOff;
	private boolean destroyed;
	private int attempt;
	private String address;
	private String localAddresses = "";
	private String note;
	private boolean badNote;
	private LanSession session;

	LanPage(final LauncherActivity activity) {
		super(activity);
	}

	void show() {
		if (this.destroyed || this.handedOff) {
			return;
		}
		if (this.address == null) {
			this.address = this.activity.preferences.getString("lan.lastHost", "");
			this.worker.execute(() -> {
				final String addresses = String.join(" / ", LanAddresses.local());
				this.activity.runOnUiThread(() -> {
					this.localAddresses = addresses;
					refresh();
				});
			});
		}
		if (this.maps == null && !this.readingMaps) {
			this.readingMaps = true;
			this.activity.catalog.maps(found -> {
				this.readingMaps = false;
				this.maps = found == null ? java.util.Collections.emptyList() : found;
				refresh();
			});
		}
		final LauncherBoard b = this.activity.board;
		final FrameLayout view = this.activity.homePage.shell(LauncherActivity.RAIL_LAN);
		final FrameLayout content = content(view, 0);
		final LanLobby lobby = this.session == null ? null : this.session.client.lobby();
		place(content, text(getString(R.string.lan_title), b.title, this.activity.art.gold()), 0, 0, b.contentW, b.title * 1.35f);
		final float top = b.tablet ? 88 : 58;
		final float leftW = b.contentW * 0.46f;
		final float gap = b.tablet ? 30 : 16;
		final FrameLayout left = framed(content, 0, top, leftW, b.contentH - top);
		final FrameLayout right = framed(content, leftW + gap, top, b.contentW - leftW - gap, b.contentH - top);
		final float inset = b.pageInset;
		final LinearLayout list = scrollList(left, inset, inset, leftW - 2 * inset, b.contentH - top - 2 * inset);
		final LinearLayout detail = scrollList(right, inset, inset, b.contentW - leftW - gap - 2 * inset,
				b.contentH - top - 2 * inset);
		if (lobby == null) {
			mapList(list);
			landing(detail);
			action(view, 0, getString(R.string.lan_back), v -> this.activity.homePage.showHome());
			final View join = action(view, 1, getString(R.string.lan_join), v -> join());
			join.setEnabled(!this.connecting);
			final View host = action(view, 2, getString(R.string.lan_host), v -> host());
			host.setEnabled(this.selected != null && !this.connecting && !this.readingMap);
		}
		else {
			lobbyList(list, lobby);
			lobbyDetails(detail, lobby);
			action(view, 0, getString(R.string.lan_leave), v -> {
				leave();
				show();
			});
			final LanLobby.Slot local = lobby.slot(this.session.client.player());
			final View ready = action(view, 1, getString(local.ready ? R.string.lan_not_ready : R.string.lan_ready), v -> {
				if (this.session != null && this.verified != null) {
					this.session.client.ready(!local.ready, this.verified.lobby.mapHash,
							this.verified.lobby.dataChecksum, this.verified.lobby.graphics);
				}
			});
			ready.setEnabled(this.verified != null && !lobby.started);
			final boolean host = this.session.server != null;
			final View start = action(view, 2, getString(host ? R.string.lan_start : R.string.lan_wait_host), v -> {
				if (this.session != null) {
					this.session.client.startGame();
				}
			});
			start.setEnabled(host && lobby.canStart());
		}
		this.activity.setPage(view, LauncherActivity.PAGE_LAN);
	}

	private void refresh() {
		if (!this.destroyed && !this.handedOff && this.activity.shown == LauncherActivity.PAGE_LAN) {
			show();
		}
	}

	private void line(final LinearLayout parent, final CharSequence value, final int color, final int maxLines) {
		final LauncherBoard b = this.activity.board;
		final TextView text = lines(value, b.body, color, maxLines);
		final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(MATCH, -2);
		params.bottomMargin = px(b.tablet ? 28 : 16);
		parent.addView(text, params);
	}

	private void mapList(final LinearLayout list) {
		line(list, getString(R.string.lan_maps), this.activity.art.gold(), 2);
		if (this.maps == null) {
			line(list, getString(R.string.game_loading_list), this.activity.art.text2(), 2);
			return;
		}
		int count = 0;
		for (final GameCatalog.MapEntry entry : this.maps) {
			if (!entry.melee || entry.players < 2) {
				continue;
			}
			count++;
			final LinearLayout row = new LinearLayout(this.activity);
			row.setOrientation(LinearLayout.VERTICAL);
			row.setGravity(Gravity.CENTER_VERTICAL);
			row.setPadding(px(10), px(8), px(10), px(8));
			row.addView(text(LauncherKit.glueText(entry.label), this.activity.board.body, this.activity.art.text()));
			row.addView(text(getString(R.string.lan_map_players, entry.players) + " · " + LanMapData.fileName(entry.path),
					this.activity.board.small, this.activity.art.text2()));
			markRow(row, entry.path.equals(this.selectedPath));
			row.setEnabled(!this.connecting);
			onTap(row, false, v -> select(entry.path));
			list.addView(row, new LinearLayout.LayoutParams(MATCH, px(this.activity.board.tablet ? 130 : 96)));
		}
		if (count == 0) {
			line(list, getString(R.string.lan_no_maps), this.activity.art.text2(), 5);
		}
	}

	private void landing(final LinearLayout detail) {
		line(detail, getString(R.string.lan_instructions), this.activity.art.text(), 7);
		if (this.selected != null) {
			line(detail, LauncherKit.glueText(this.selected.lobby.mapName), this.activity.art.gold(), 2);
		}
		line(detail, getString(R.string.lan_host_address), this.activity.art.gold(), 1);
		final EditText field = nameField(this.activity.board.body);
		field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
		field.setFilters(new InputFilter[] { new InputFilter.LengthFilter(32) });
		field.setHint("192.168.43.1");
		field.setContentDescription(getString(R.string.lan_host_address));
		field.setText(this.address);
		afterTextChanged(field, () -> this.address = field.getText().toString());
		detail.addView(field, new LinearLayout.LayoutParams(MATCH, px(this.activity.board.buttonH)));
		if (this.connecting || this.readingMap || this.note != null) {
			line(detail, this.connecting ? getString(R.string.lan_connecting)
					: this.readingMap ? getString(R.string.lan_checking) : this.note,
					this.badNote ? ERROR : this.activity.art.text2(), 5);
		}
		line(detail, getString(R.string.lan_same_files), this.activity.art.text2(), 6);
	}

	private void lobbyList(final LinearLayout list, final LanLobby lobby) {
		line(list, LauncherKit.glueText(lobby.mapName), this.activity.art.gold(), 2);
		line(list, getString(R.string.lan_player_count, lobby.playerCount(), lobby.slots.size()), this.activity.art.text2(), 1);
		final String[] races = glueList(com.etheller.warsmash.launcher.CustomGame.RACES, 0);
		for (final LanLobby.Slot slot : lobby.slots) {
			final LinearLayout row = new LinearLayout(this.activity);
			row.setOrientation(LinearLayout.VERTICAL);
			row.setGravity(Gravity.CENTER_VERTICAL);
			row.setPadding(px(10), px(8), px(10), px(8));
			row.addView(text(slot.occupied() ? slot.name : getString(R.string.lan_empty), this.activity.board.body,
					slot.occupied() ? this.activity.art.text() : this.activity.art.text2()));
			if (slot.occupied()) {
				row.addView(text(getString(R.string.lan_slot_detail, slot.team + 1, races[slot.race],
						getString(slot.ready ? R.string.lan_ready : R.string.lan_waiting)), this.activity.board.small,
						slot.ready ? this.activity.art.gold() : this.activity.art.text2()));
			}
			markRow(row, slot.player == this.session.client.player());
			list.addView(row, new LinearLayout.LayoutParams(MATCH, px(this.activity.board.tablet ? 130 : 96)));
		}
	}

	private void lobbyDetails(final LinearLayout detail, final LanLobby lobby) {
		if (this.session.server != null) {
			line(detail, getString(R.string.lan_share_ip), this.activity.art.gold(), 3);
			final TextView ip = lines(this.localAddresses.isEmpty() ? getString(R.string.lan_no_ip)
					: this.localAddresses + ":" + this.session.server.port(), this.activity.board.body, this.activity.art.text(), 4);
			ip.setTextIsSelectable(true);
			detail.addView(ip);
		}
		else {
			line(detail, getString(R.string.lan_connected, this.address), this.activity.art.gold(), 2);
		}
		line(detail, this.note != null ? this.note : getString(R.string.lan_checking),
				this.badNote ? ERROR : this.activity.art.text2(), 5);
		final LanLobby.Slot local = lobby.slot(this.session.client.player());
		line(detail, getString(R.string.lan_your_race), this.activity.art.gold(), 1);
		final String[] races = glueList(com.etheller.warsmash.launcher.CustomGame.RACES, 0);
		detail.addView(dropdown(races, local.race, !lobby.started, this.activity.board.buttonH,
				this.activity.board.body, race -> {
					if (this.session != null) {
						this.session.client.choose(race, local.team);
					}
				}), new LinearLayout.LayoutParams(MATCH, px(this.activity.board.buttonH)));
		line(detail, getString(R.string.lan_your_team), this.activity.art.gold(), 1);
		final String[] teams = new String[LanLobby.MAX_PLAYERS];
		for (int i = 0; i < teams.length; i++) {
			teams[i] = getString(R.string.lan_team, i + 1);
		}
		detail.addView(dropdown(teams, local.team, !lobby.started, this.activity.board.buttonH,
				this.activity.board.body, team -> {
					if (this.session != null) {
						this.session.client.choose(local.race, team);
					}
				}), new LinearLayout.LayoutParams(MATCH, px(this.activity.board.buttonH)));
		line(detail, getString(R.string.lan_ready_help), this.activity.art.text2(), 6);
	}

	private void select(final String path) {
		this.selectedPath = path;
		this.selected = null;
		this.readingMap = true;
		this.note = null;
		this.badNote = false;
		refresh();
		this.activity.catalog.lanMap(path, found -> {
			if (!path.equals(this.selectedPath) || this.destroyed) {
				return;
			}
			this.readingMap = false;
			this.selected = found;
			this.note = getString(found == null ? R.string.lan_map_unreadable : R.string.lan_map_ok);
			this.badNote = found == null;
			refresh();
		});
	}

	private void host() {
		if (this.selected != null && !this.connecting) {
			connect(null, this.selected);
		}
	}

	private void join() {
		try {
			final InetSocketAddress endpoint = LanAddresses.parse(this.address);
			this.activity.preferences.edit().putString("lan.lastHost", this.address.trim()).apply();
			connect(endpoint, null);
		}
		catch (final IllegalArgumentException e) {
			this.activity.dialogs.showMessage(getString(R.string.lan_title), e.getMessage());
		}
	}

	private void connect(final InetSocketAddress endpoint, final LanMapData hostMap) {
		if (this.connecting || this.session != null) {
			return;
		}
		this.connecting = true;
		this.note = null;
		this.badNote = false;
		final int attempt = ++this.attempt;
		final String name = this.activity.profiles.current();
		refresh();
		this.worker.execute(() -> {
			LanServer server = null;
			try {
				if (hostMap != null) {
					server = new LanServer(hostMap.lobby, LanServer.DEFAULT_PORT);
				}
				final InetSocketAddress remote = server != null
						? new InetSocketAddress(InetAddress.getByAddress(new byte[] { 127, 0, 0, 1 }), server.port()) : endpoint;
				final LanClient client = LanClient.connect(remote, GameReplays.engineVersion(), name, server != null ? server.hostKey() : null);
				final LanSession session = new LanSession(client, server);
				final String addresses = String.join(" / ", LanAddresses.local());
				this.activity.runOnUiThread(() -> {
					if (attempt != this.attempt || this.destroyed || this.activity.shown != LauncherActivity.PAGE_LAN) {
						session.close();
						return;
					}
					this.localAddresses = addresses;
					this.connecting = false;
					this.session = session;
					this.verified = hostMap;
					if (hostMap != null) {
						session.setLocalMap(hostMap.path);
						this.note = getString(R.string.lan_verified);
					}
					LanSession.install(session);
					this.activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
					session.client.setListener(() -> this.activity.runOnUiThread(() -> changed(session)));
				});
			}
			catch (final Exception e) {
				if (server != null) {
					server.close();
				}
				android.util.Log.w(LauncherActivity.TAG, "LAN setup failed", e);
				this.activity.runOnUiThread(() -> {
					if (attempt == this.attempt && !this.destroyed) {
						this.connecting = false;
						this.note = getString(hostMap != null ? R.string.lan_host_failed : R.string.lan_join_failed);
						this.badNote = true;
						refresh();
					}
				});
			}
		});
	}

	private void changed(final LanSession session) {
		if (session != this.session || this.destroyed || this.handedOff) {
			return;
		}
		if (session.client.error() != null) {
			final String error = session.client.error();
			leave();
			this.note = error;
			this.badNote = true;
			refresh();
			return;
		}
		final LanLobby lobby = session.client.lobby();
		if (lobby == null) {
			return;
		}
		if (lobby.started) {
			if (this.verified == null || session.localMap() == null) {
				session.client.abort(getString(R.string.lan_map_mismatch));
				return;
			}
			this.handedOff = true;
			session.client.setListener(null);
			final LaunchRequest request = new LaunchRequest();
			request.lanSession = session.id;
			request.mapFile = session.localMap();
			request.slots = LanGameSetup.loadingSlots(lobby, session.client.player());
			this.activity.launchGame(request, LauncherActivity.PAGE_LAN);
			return;
		}
		if (this.verified == null && !this.checking) {
			this.checking = true;
			this.note = getString(R.string.lan_checking);
			this.activity.catalog.findLanMap(lobby, found -> {
				if (this.session != session || this.destroyed) {
					return;
				}
				if (found != null && found.matches(lobby)) {
					this.verified = found;
					session.setLocalMap(found.path);
					this.note = getString(R.string.lan_verified);
				}
				else {
					this.note = getString(found == null ? R.string.lan_map_mismatch : R.string.lan_data_mismatch);
					this.badNote = true;
				}
				refresh();
			});
		}
		refresh();
	}

	void back() {
		if (this.session != null || this.connecting) {
			leave();
			show();
		}
		else {
			this.activity.homePage.showHome();
		}
	}

	void leave() {
		if (this.handedOff) {
			return;
		}
		this.attempt++;
		this.connecting = false;
		this.checking = false;
		this.verified = null;
		this.note = null;
		this.badNote = false;
		if (this.session != null) {
			this.session.close();
			this.session = null;
		}
		this.activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	}

	void destroy() {
		this.destroyed = true;
		leave();
		this.worker.shutdownNow();
	}
}
