Perbaikan seleksi dan perintah pekerja — versi 0.3.6.3 (versionCode 4)

Ketukan ke unit ramah sekarang mengganti pilihan sebelumnya. Ketukan pekerja
ke tambang, tempat setor hasil, atau bangunan yang bisa diperbaiki/dibantu
menjalankan pekerjaan yang sesuai dan mempertahankan pilihan pekerja.

Penyebabnya ada pada routing sentuh: unit biasa selalu menerima klik kanan saat
ada pilihan aktif, sedangkan bangunan ramah selalu mengambil alih sebagai seleksi.
Akibatnya, mengetuk unit lain mengirim perintah mengikuti dan mengetuk bangunan
menghilangkan pilihan pekerja sebelum perintah diberikan.

- `RtsTouchAdapter` memakai `TouchTarget.selectUnitAt()` untuk ketukan unit ramah.
  Jalur ini diteruskan oleh MapScreen, MeleeToggleUI, dan MeleeUI ke MeleeUIInput.
  Pilihan diganti melalui `applySelection()` agar lingkaran, penerima perintah,
  portrait, command card, dan event seleksi tetap sesuai.
- Bangunan ramah hanya menjadi seleksi jika pekerja terpilih tidak memiliki
  tindakan yang cocok. `SmartTargetOrder` memakai pemeriksaan kemampuan asli
  untuk harvest, Acolyte/Wisp harvest, setor hasil, repair, dan Human power build.
  Kemampuan harus aktif, target harus diterima, dan pekerja harus bisa dikendalikan.
- Resolver yang sama dipakai untuk perintah target sesungguhnya. Tindakan pekerja
  diprioritaskan atas follow/move tanpa bergantung urutan kemampuan. Perintah tetap
  dikirim melalui `unitOrderListener` dengan target dan status antrean Shift.
- Harvest menolak tempat setor jika jumlah barang bawaan sudah nol, meskipun
  jenis hasil terakhir masih tersimpan setelah penyetoran.
- Double tap hanya dimulai dari ketukan seleksi dan hanya memperluas unit yang
  sama dengan ketukan pertama. Dua unit berbeda yang berdekatan dipilih bergantian.
  Double tap bangunan tetap memilih satu bangunan. Perintah kerja/tanah tidak
  dapat menjadi ketukan awal untuk memperluas seleksi.
- Shift sengaja menambah/mengurangi pilihan unit. Seleksi bangunan tetap eksklusif.
  Tahan-lepas dapat memilih bangunan meskipun pekerja sedang terpilih. Target
  kemampuan, placement, kotak seleksi, input pena, dan kamera memakai jalur semula.
- Bantuan launcher dan panduan kontrol disesuaikan. Pengaturan performa dan mod
  yang sudah ada tetap tersedia dalam APK pembaruan.

Pengujian tanpa emulator mencakup urutan pointer nyata melalui recognizer/adapter,
aturan seleksi produksi, dan kemampuan pekerja asli untuk tiga jenis tambang.
Tes konstruksi memulai CBehaviorHumanRepair, memeriksa penetapan pekerja, kenaikan
progres/HP, dan pelepasan pekerja saat pekerjaan dihentikan. Fixture menyediakan
objek terlihat dan dalam jangkauan; tes ini tidak mengukur pathfinding atau UI HP.

Build dari akar repositori dengan JDK 21 dan Android SDK yang dikonfigurasi:

```
./gradlew :core:test :android:lintDebug :android:assembleDebug --no-daemon --max-workers=2 --console=plain
```

Panduan tersedia di [panduan kontrol](docs/PANDUAN-KONTROL-INDONESIA.txt).
Hasil build dan checksum paket terkini tersedia di
[verifikasi 0.3.6.4](docs/VERIFIKASI-v0.3.6.4.md). Perbaikan versi ini sudah
termasuk dalam source 0.3.6.4 yang disertakan.
