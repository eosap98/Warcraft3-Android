# Perbaikan kontrol dan menu sumber daya — 0.3.6.1

Catatan perubahan versi 0.3.6.1. APK dibangun dari source tanpa menjalankan emulator.

## Seleksi

- Tap dua jari memanggil pembatalan target dan pengosongan seleksi secara langsung. Jalur ini juga melepaskan listener seleksi kelompok agar unit yang kemudian mati tidak mengakses panel seleksi lama.
- Double tap dibedakan memakai timestamp event, dengan interval 400 ms dan toleransi posisi sesuai kepadatan layar. Ketukan kedua pada unit memilih unit sejenis yang terlihat dan memiliki pemilik sama. Konfirmasi kemampuan, tombol UI, perintah tanah, dan pen tetap mempunyai jalurnya sendiri.
- Kotak seleksi menyimpan koordinat layar yang juga digunakan untuk menggambar batasnya. Kandidat diambil dari unit render, sehingga rotasi kamera dan unit terbang tidak bergantung pada persegi di sumbu dunia atau pohon collision.
- Saat pelepasan jari, kandidat dihitung ulang dengan posisi terakhir. Daftar preview dari frame sebelumnya tidak menjadi sumber hasil seleksi. Pelepasan seleksi juga tidak mengirim hover sintetis yang sebelumnya menghapus preview.
- Lingkaran seleksi, daftar penerima perintah, dan event simulasi menggunakan kelompok yang sama. Batas engine tetap **24 unit**; seleksi tipe berlaku untuk unit di layar.
- Pembatalan input ketika menu dimunculkan atau aplikasi dijeda juga membersihkan Shift virtual dan status palm filter.

## Menu mod

`InGameModMenu` adalah overlay native di dalam activity game, dengan panel transparan dan ikon titik yang dapat dipindahkan. Panel bisa ditutup ke ikon atau disembunyikan; tiga jari memunculkan kembali ikon tersembunyi. Posisi dan status tersembunyi disimpan melalui preferences. Stream sentuhan yang dimulai pada overlay tidak diteruskan ke permainan.

Tombol menambah 1.000 emas, 1.000 kayu, atau 10.000 keduanya kepada pemain sendiri. `CPlayerResourceBoost` memakai jalur perintah dan pencatatan engine, berbeda dari kode cheat bawaan yang menambah sumber daya semua pemain. Nilai divalidasi dan dijenuhkan di batas integer supaya penekanan berulang tidak menghasilkan saldo negatif. Save/replay merekam perubahan melalui mekanisme perintah yang sama.

Menu hanya tersedia ketika permainan pemain tunggal menerima kontrol, di luar sinematik, menu jeda, replay, dan hasil pertandingan. Akses simulasi tetap dilakukan pada thread render.

## Render

`AndroidFramePacer` meminta render dari callback layar memakai `FrameCadence`, tanpa sleep pada thread UI/render dan tanpa mengejar backlog frame setelah jeda panjang. Game menyediakan batas 30/60 FPS melalui Pengaturan > Grafik, dengan nilai awal 60. Animasi latar 3D launcher dibatasi 30 FPS; latar statis/gagal serta activity yang dijeda tidak mempertahankan render berkelanjutan. Sensor gerakan yang tidak dipakai game dinonaktifkan.

## Verifikasi

- Tes JVM menguji gesture mentah melalui recognizer/adapter, pembatalan router, seleksi dengan kamera berotasi dan unit terbang, hasil akhir tanpa preview, resource pemain sendiri beserta replay/overflow, serta cadence pada layar 60/90/120/144 Hz.
- Build: `:core:test :android:lintDebug :android:assembleDebug` dengan JDK lokal, Gradle offline, dan dua worker.
- APK diperiksa dengan `apksigner`, `zipalign -c -P 16 4`, CRC ZIP, identitas package/version, keberadaan kelas baru, serta perbandingan resource kamus Indonesia dengan APK sebelumnya.
- Hasil pemeriksaan versi paket terbaru tersedia di [verifikasi 0.3.6.4](docs/VERIFIKASI-v0.3.6.4.md).

Belum ada uji sentuhan native atau pengukuran FPS pada perangkat Android fisik. Target FPS tidak menyatakan FPS minimum yang terjamin.
