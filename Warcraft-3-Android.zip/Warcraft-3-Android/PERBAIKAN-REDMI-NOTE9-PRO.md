Perbaikan Redmi Note 9 Pro — versi 0.3.6.2 (versionCode 3)

Versi ini menambahkan pengurangan beban render, penyesuaian
input pada resolusi rendah, titik/menu mod yang bebas dipindahkan, dan seleksi
bangunan yang mengganti pasukan. Build dilakukan tanpa emulator.

- `AndroidLauncher` meminta mode layar 60 Hz dengan ukuran fisik yang sama dan
  memakai render kontinu libGDX untuk target 60 FPS. GL swap mengatur vsync tanpa
  pengiriman permintaan render setiap frame dari UI thread. Callback tetap digunakan
  untuk 30 FPS dan layar tanpa mode 60 Hz; pacing launcher tidak berubah.
- `AndroidGameSurface` memakai `SurfaceHolder.setFixedSize()` untuk buffer yang
  dibatasi sisi pendeknya. `RenderResolution` memilih 720 secara bawaan, dengan
  opsi 540 atau 0 (Asli) di `[Graphics] RenderShortEdge`. Buffer tidak diperbesar
  pada jendela kecil. Ukuran viewport mengikuti rasio layar, termasuk saat resize.
- Untuk bidang 2400×1080, 720p menghasilkan 1600×720, yaitu 4/9 jumlah piksel awal.
  540p menghasilkan 1200×540. Ini perhitungan beban piksel; bukan pengukuran FPS.
  Seluruh surface game, termasuk HUD, diubah ukurannya. Menu Android tetap tajam.
- Pointer finger/pen tetap diantrikan dalam piksel view fisik. `TouchInputRouter`
  mengonversinya pada GL thread setelah backend memperbarui ukuran surface.
  `TouchSettings.scaled()` menjaga ukuran fisik ambang gesture dan palm rejection.
  Input mouse dan mode TouchControls=Off dikonversi pada listener view libGDX;
  event overlay native tidak melewati konversi ini. `InputViewport` juga dipakai
  untuk toleransi seleksi dan tinggi keyboard. Resize membatalkan gesture lama.
- Pass `Scene.renderOpaque(DynamicShadowManager, WebGL)` sebelumnya hanya
  membersihkan depth framebuffer 1024×1024: loop caster dinonaktifkan dan hasil
  depth tidak disampling terrain. `War3MapViewer` kini tidak mengalokasikan atau
  menjalankan pass tersebut. `Terrain` tetap memakai shadow map peta dan splat
  bayangan unitnya. Tidak ada perubahan ke simulasi atau langkah waktu game.
- `InGameModMenu` menggambar titik 6 dp dalam area sentuh transparan 48 dp.
  Batas gerak mempertimbangkan titik yang terlihat, sehingga padding tidak
  menahan titik di tepi. Panel memiliki posisi dan drag sendiri, tanpa mengikuti
  titik ketika diseret. Sebagian panel boleh melampaui tepi; judul tetap terjangkau.
  Posisi titik/panel disimpan sebagai rasio. Layout pertama panel diperhitungkan
  sebelum penempatan akhir, termasuk setelah dibuka dari keadaan GONE.
- `TouchTarget.selectBuildingAt()` diteruskan melalui MapScreen dan MeleeToggleUI
  ke MeleeUIInput. Bangunan milik sendiri, shared control, atau sekutu pasif dipilih
  secara eksklusif. `applySelection()` memperbarui lingkaran, daftar penerima perintah,
  portrait, command card, dan event seleksi sekaligus. Perintah aktif dan placement
  tidak diambil alih; tap musuh tetap memberi perintah. Seleksi bangunan melalui
  tahan-lepas mengabaikan penambahan Shift/Ctrl khusus finger. Mouse tetap mengikuti
  perilaku desktop. Double tap dekat bangunan juga tidak membawa pasukan lama.

274 tes JVM lulus (0 gagal/error/skipped); Android Lint 0 error dan 62 warning.
Tes baru memeriksa input/resolusi dan seleksi bangunan, termasuk perilaku Shift,
Ctrl, pen, kemampuan aktif, placement, palm rejection, dan pembatalan saat resize.
SuppressLint pada penerus input surface menjelaskan bahwa gesture ditangani libGDX;
listener klik tombol native tidak diubah.

APK lolos verifikasi signature v2, ZIP CRC, alignment 16 KB, metadata, dan kelas DEX.
Kedua resource kamus Indonesia dipertahankan identik. Sertifikat debug sama dengan
APK sebelumnya sehingga pemasangan pembaruan didukung. Metadata dan checksum
paket terkini tersedia di [verifikasi 0.3.6.4](docs/VERIFIKASI-v0.3.6.4.md).

Tidak ada hasil FPS dari perangkat fisik. Stabil 60 FPS pada Redmi Note 9 Pro
masih memerlukan pengujian peta yang sama di HP tersebut. Perbaikan versi ini
sudah termasuk dalam source 0.3.6.4 yang disertakan.
