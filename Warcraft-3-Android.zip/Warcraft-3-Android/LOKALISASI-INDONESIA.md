# Lokalisasi Indonesia untuk Android

APK menggunakan Bahasa Indonesia pada launcher dan antarmuka permainan, beserta kamus teks dari data Warcraft III 1.31.1.12164 enUS yang diberikan pengguna. Nama peta, judul misi, dan nama hero dipertahankan. Instalasi game sumber tidak diubah.

Resource Android memuat 304 string. `indonesian.properties` berisi 734 entri yang dikurasi untuk menu, bantuan, perintah, pesan kesalahan, dan label statis. `indonesian-content.json.gz` memuat 18.576 entri teks, 1.301 label FDF, 1.580 pola penghitung berangka, dan 1.298 nama yang dilindungi. Kelompok tersebut dapat saling tumpang tindih.

`IndonesianUi` mengaktifkan terjemahan engine pada Android. Launcher native dapat menggunakan kamus sebelum aplikasi libGDX dibuat. Label asli tetap tersedia untuk pencocokan tombol pintas, sehingga menerjemahkan menu tidak mengubah tombol keyboard yang berasal dari FDF.

`IndonesianContent` menerjemahkan teks pada saat ditampilkan. Keterangan kemampuan diterjemahkan sebelum referensi seperti `<AHhb,DataA1>` diisi dengan angka permainan. Data objek dan string yang disimpan dalam simulasi atau script JASS tetap asli. Judul peta dan misi menggunakan jalur tampilan aslinya; nama hero juga dilindungi berdasarkan jenis unit. Teks dari peta lain yang tidak ditemukan dalam kamus tetap ditampilkan sebagaimana diberikan oleh peta tersebut.

Kamus konten mencakup dialog cerita, deskripsi dan persyaratan misi, kemampuan, item, unit biasa, bangunan, peningkatan, objek lingkungan, pesan, penghitung waktu, papan skor, serta narasi pemuatan klasik dan Reforged. Suara dan sulih suara tetap berasal dari data game asli.

## Sumber dan pembuatan kamus

Teks diekstrak dengan pembaca CASC dan MPQ milik engine dari 300 peta, data objek standar, perubahan objek peta, WTS, teks tampilan JASS, dan FDF. Nama hero standar dan khusus, judul peta, serta judul misi dikumpulkan sebelum penerjemahan. Proses awal menggunakan skrip berikut dalam direktori kerja lokal yang terpisah dari repositori:

- `ExtractTexts.java`, `ExportMapTexts.java`, dan `ExtraGameTexts.java`: membaca data sumber tanpa menulis ke instalasi game.
- `prepare_corpus.py`: memilih teks tampilan dan mengumpulkan nama yang dilindungi.
- `translate_corpus.py`: membuat kamus terkompresi, mempertahankan parameter, dan membentuk pola penghitung yang tidak ambigu.
- `reviewed-translations.json`: glosarium tambahan serta koreksi manual, termasuk petunjuk tutorial untuk kontrol sentuh.
- `model/source.json`: identitas model dan hash berkas yang digunakan.

Penerjemahan otomatis dilakukan secara lokal dengan CTranslate2 4.8.5 dan varian `lora-ct2-int8` dari [WindyWord/translate-en-id](https://huggingface.co/WindyWord/translate-en-id/tree/a553695df171b5fd849d198e4622c7ddae0d9cc5), revision `a553695df171b5fd849d198e4622c7ddae0d9cc5`. Model tersebut merupakan turunan Helsinki OPUS-MT en-id dengan lisensi Apache-2.0. Lisensi dan pemberitahuan sumber disimpan bersama model di direktori kerja. Bobot model tidak dimasukkan ke APK; aplikasi hanya membaca hasil kamus dan tidak membutuhkan layanan penerjemahan daring.

Koreksi manual dan glosarium memperbaiki istilah permainan yang sering muncul. Sebagian kalimat hasil mesin masih dapat terasa kaku; teks atau variasi dari data yang berbeda dapat tetap menggunakan bahasa aslinya. Kamus ini tidak menyatakan dukungan terjemahan untuk setiap peta buatan pengguna.

Paket GitHub memuat kamus akhir di `core/src/main/resources/com/etheller/warsmash/localization/`.
Build aplikasi membaca kamus tersebut secara langsung; Python dan bobot model tidak
diperlukan untuk build. Skrip ekstraksi, lingkungan penerjemahan, serta bahan game
yang digunakan dalam proses awal tidak menjadi bagian dari paket ini.

## Verifikasi

`IndonesianContentTest` memeriksa seluruh referensi parameter dan angka yang terlihat, perlindungan semua nama, teks yang tidak dikenal, dialog yang dikoreksi, pembatasan platform, dan angka dinamis dari script. `IndonesianUiTest` memeriksa label, format, pesan kesalahan, dan kunci asli menu. Tes kontrol sentuh dan tombol pintas juga dijalankan bersama seluruh suite core.

Build lokalisasi awal lulus 227 tes core dan Android Lint dengan 0 error serta 61 warning. APK diperiksa dengan `aapt2`, `apksigner`, `zipalign`, CRC ZIP, dan perbandingan kamus di dalam APK dengan resource sumber. Emulator tidak digunakan; permainan belum diuji pada perangkat Android fisik. Angka tersebut merupakan hasil versi awal; hasil paket 0.3.6.4 dicatat pada [verifikasi terbaru](docs/VERIFIKASI-v0.3.6.4.md).

Perintah build dari direktori proyek, setelah JDK 21 dan Android SDK dikonfigurasi:

```bash
./gradlew :core:test :android:lintDebug :android:assembleDebug --no-daemon --max-workers=2 --console=plain
```

Lihat [panduan kontrol](docs/PANDUAN-KONTROL-INDONESIA.txt) dan
[panduan upload](docs/CARA-UPLOAD-GITHUB.md) untuk lokasi APK serta checksum.
