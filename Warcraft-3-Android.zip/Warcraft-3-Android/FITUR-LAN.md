# LAN Android — 0.3.6.4

Menu **Jaringan lokal (LAN)** pada launcher Android membuka lobi untuk bermain
bersama melalui Wi-Fi atau hotspot. Satu HP menjadi host sekaligus pemain;
server berjalan di aplikasi itu sendiri. Perangkat lain bergabung dengan IP host.

## Cara bermain

1. Pasang APK versi LAN yang sama di semua HP. Gunakan data game, set grafis,
   serta berkas peta dengan isi dan nama file yang sama.
2. Hubungkan HP ke Wi-Fi yang sama, atau aktifkan hotspot pada salah satu HP
   dan hubungkan HP lain ke hotspot itu. Internet tidak diperlukan.
3. Host membuka **Jaringan lokal (LAN)**, memilih peta melee, lalu **Buat Ruang**.
   IP host ditampilkan dalam lobi. Tekan lama teks IP untuk menyalinnya.
4. Teman membuka menu LAN, memasukkan IP tersebut, lalu **Gabung**.
   Aplikasi mencari peta yang cocok dalam katalog lokal. Folder peta boleh berbeda.
5. Setiap pemain memilih ras dan tim, lalu menekan **Siap**. Harus ada setidaknya
   dua pemain dan dua tim. Host menekan **Mulai Battle** setelah semuanya siap.
6. Permainan menunggu semua HP selesai memuat peta. Biarkan aplikasi tetap
   terbuka selama pertandingan, terutama pada HP host.

Saat pemain baru masuk, keluar dari lobi, atau mengubah ras/tim, semua pemain
harus menekan Siap kembali. Slot yang belum terisi tidak mendapat pasukan awal.
Pilihan ras Acak memakai seed yang sama di semua perangkat.

## Cakupan

- Launcher Android, 2–12 pemain manusia sesuai slot peta.
- Peta melee dengan skrip JASS, tanpa custom forces. Peta kampanye, Lua, dan
  custom game seperti Dota belum menjadi bagian dari alur LAN ini.
- Gabung langsung melalui IPv4, dengan port TCP 6112 secara bawaan. Kolom IP
  juga menerima bentuk `192.168.43.1:6112`.
- Kedua perangkat menyediakan petanya sendiri; lobi memeriksa SHA-256 peta,
  versi engine, set grafis, serta checksum data aturan permainan.
- Perintah unit, formasi, serangan, kemampuan, seleksi, chat, dan perintah pemain
  lain memakai codec perintah engine yang sama. Identitas pemain berasal dari
  koneksinya dan otorisasi kontrol unit tetap diperiksa oleh executor engine.
- Simpan/muat, restart, pause manual, dan menu tambah sumber daya tidak tersedia
  untuk pertandingan LAN.

## Sinkronisasi dan siklus hidup

`LanServer` mengirim satu batch per langkah setelah seluruh pemain aktif
mengirim input. Batch selalu memiliki urutan pemain yang sama. `LanTurnManager`
menerapkannya sekali sebelum langkah simulasi, pada thread permainan. Tidak ada
perubahan simulasi yang dijalankan oleh thread pembaca soket.

Konfigurasi pemain, nama, ras, tim, seed, kecepatan awal, dan pengacakan posisi
awal disamakan. Kesiapan memuat baru dikirim setelah UI dan skrip utama peta
dibangun. Checksum keadaan awal dan setiap 20 langkah mendeteksi perbedaan
simulasi; jika berbeda, pertandingan berhenti dengan pesan yang jelas.

`LanSession` mempertahankan soket ketika launcher menyerahkan layar ke activity
game. ID sesi tidak dapat menghidupkan kembali koneksi setelah proses Android
hilang. Keluar lobi, gagal memulai game, menutup game, dan activity dihancurkan
membersihkan koneksi. Port host dapat dipakai kembali.

Soket mengirim heartbeat setiap 2 detik dan mendeteksi koneksi yang tidak
merespons setelah 15 detik. Batas pemuatan adalah 5 menit, dan batas menunggu
progres pertandingan 45 detik. Pemain tamu yang terputus/keluar dilepas dari
barrier dan menghasilkan perintah keluar yang sama pada pemain tersisa.
Jika host menutup aplikasi atau ruang, pertandingan berakhir untuk tamu.

## Pemeriksaan tanpa emulator

Tes JVM memakai soket TCP sungguhan untuk host dan beberapa klien, termasuk
perintah yang diterapkan pada dua objek simulasi. Tes juga memeriksa kesiapan,
otoritas host, slot, penolakan versi/peta/data berbeda, paket terfragmentasi,
checksum tidak cocok, pemain keluar, dan penggunaan ulang port.

Tes tersebut tidak menggantikan uji pertandingan lengkap pada dua HP fisik.
Build ini tidak menjalankan emulator. Hasil build akhir, jumlah tes, metadata
APK, serta checksum dicatat di [hasil pemeriksaan paket](docs/VERIFIKASI-v0.3.6.4.md).

## Berkas implementasi

- `android/.../LanPage.java`: alur host/join, peta lokal, ras/tim, dan kesiapan.
- `core/.../networking/lan/`: protokol, koneksi, server, klien, sesi, dan barrier.
- `core/.../launcher/LanMapData.java`: identitas peta dan data aturan game.
- `MenuMapStart`, `LaunchRequest`, `LaunchContract`: penyerahan lobi ke game.
- `AndroidLauncher`: pesan menunggu, kegagalan koneksi, dan penutupan sesi.

Source versi 0.3.6.4 dalam repositori ini juga mencakup lokalisasi, perbaikan
kontrol, penyesuaian render, serta perintah pekerja dari versi sebelumnya.
