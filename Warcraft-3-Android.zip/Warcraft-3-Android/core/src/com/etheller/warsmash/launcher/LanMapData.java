package com.etheller.warsmash.launcher;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

import com.etheller.warsmash.datasources.BorrowedDataSource;
import com.etheller.warsmash.datasources.DataSource;
import com.etheller.warsmash.datasources.GraphicsSet;
import com.etheller.warsmash.datasources.GraphicsSettings;
import com.etheller.warsmash.networking.lan.LanLobby;
import com.etheller.warsmash.parsers.w3x.War3Map;
import com.etheller.warsmash.parsers.w3x.objectdata.Warcraft3MapObjectData;
import com.etheller.warsmash.parsers.w3x.w3i.Player;
import com.etheller.warsmash.parsers.w3x.w3i.War3MapW3i;
import com.etheller.warsmash.parsers.w3x.w3i.War3MapW3iFlags;
import com.etheller.warsmash.units.DataTable;
import com.etheller.warsmash.util.WarsmashConstants;
import com.etheller.warsmash.viewer5.handlers.w3x.War3MapViewer;
import com.etheller.warsmash.viewer5.handlers.w3x.replay.GameReplays;

/** Proof of a local map and its game rules; only the file name and checksums travel over the network. */
public final class LanMapData {
	public final String path;
	public final LanLobby lobby;

	private LanMapData(final String path, final LanLobby lobby) {
		this.path = path;
		this.lobby = lobby;
	}

	public boolean matches(final LanLobby host) {
		return this.lobby.engineVersion.equals(host.engineVersion) && this.lobby.mapHash.equals(host.mapHash)
				&& this.lobby.dataChecksum == host.dataChecksum && this.lobby.graphics.equals(host.graphics);
	}

	public static String fileName(final String path) {
		final String normal = path.replace('\\', '/');
		return normal.substring(normal.lastIndexOf('/') + 1);
	}

	static LanMapData read(final DataSource source, final DataTable ini, final String path) throws IOException {
		final War3Map map = new War3Map(source, path);
		final LanLobby lobby = new LanLobby();
		GraphicsSet graphics = GraphicsSettings.graphicsSet(ini);
		try {
			final War3MapW3i info = map.readMapInformation();
			if (!info.hasFlag(War3MapW3iFlags.MELEE_MAP) || !map.hasJassScript()
					|| info.hasFlag(War3MapW3iFlags.USE_CUSTOM_FORCES)) {
				throw new IOException("Pilih peta pertempuran melee dengan sedikitnya dua pemain.");
			}
			lobby.engineVersion = GameReplays.engineVersion();
			lobby.mapName = GameCatalog.trigStr(Warcraft3MapObjectData.loadWTS(map), info.getName());
			lobby.mapFile = fileName(path);
			for (final Player player : info.getPlayers()) {
				if (player.getType() == 1 && player.getId() >= 0 && player.getId() < WarsmashConstants.MAX_PLAYERS - 4
						&& lobby.slots.size() < LanLobby.MAX_PLAYERS) {
					lobby.slots.add(new LanLobby.Slot(player.getId(), 0, lobby.slots.size()));
				}
			}
			lobby.slots.sort((a, b) -> Integer.compare(a.player, b.player));
			if (War3MapViewer.isReforgedGraphicsMap(info) && graphics == GraphicsSet.CLASSIC) {
				graphics = GraphicsSet.REFORGED;
			}
		}
		finally {
			map.close();
		}
		lobby.mapHash = hash(source, path);
		lobby.graphics = graphics.getIniName();
		final DataSource gameData = GraphicsSettings.gameData(new BorrowedDataSource(source), ini, graphics);
		try {
			lobby.dataChecksum = GameReplays.dataChecksum(gameData);
		}
		finally {
			gameData.close();
		}
		lobby.validate();
		return new LanMapData(path, lobby);
	}

	static String hash(final DataSource source, final String path) throws IOException {
		final MessageDigest digest;
		try {
			digest = MessageDigest.getInstance("SHA-256");
		}
		catch (final NoSuchAlgorithmException e) {
			throw new IOException(e);
		}
		try (InputStream in = path.startsWith("/") || !source.has(path) ? new FileInputStream(path)
				: source.getResourceAsStream(path)) {
			if (in == null) {
				throw new IOException("Peta LAN tidak ditemukan.");
			}
			final byte[] buffer = new byte[65536];
			int read;
			while ((read = in.read(buffer)) != -1) {
				digest.update(buffer, 0, read);
			}
		}
		final StringBuilder hex = new StringBuilder(64);
		for (final byte value : digest.digest()) {
			hex.append(String.format(Locale.ROOT, "%02x", value & 255));
		}
		return hex.toString();
	}
}
