package com.etheller.warsmash.viewer5;

public interface AudioDestination {

}
