package com.etheller.warsmash.util;

/** Fits the game buffer to a short-edge limit, keeping its aspect ratio and never upscaling. */
public final class RenderResolution {
	public static final String KEY = "RenderShortEdge";
	public static final int DEFAULT_SHORT_EDGE = 720;
	public static final int[] OPTIONS = { 540, 720, 0 };
	public final int width;
	public final int height;

	private RenderResolution(final int width, final int height) {
		this.width = width;
		this.height = height;
	}

	/** The Android performance default also applies to configurations from older versions. */
	public static int configuredShortEdge(final String value) {
		if (value != null) {
			for (final int option : OPTIONS) {
				if (Integer.toString(option).equals(value.trim())) {
					return option;
				}
			}
		}
		return DEFAULT_SHORT_EDGE;
	}

	public static RenderResolution fit(final int viewWidth, final int viewHeight, final int shortEdge) {
		final int width = Math.max(1, viewWidth);
		final int height = Math.max(1, viewHeight);
		final double scale = shortEdge <= 0 ? 1 : Math.min(1, (double) shortEdge / Math.min(width, height));
		return new RenderResolution(Math.max(1, (int) Math.round(width * scale)),
				Math.max(1, (int) Math.round(height * scale)));
	}
}
