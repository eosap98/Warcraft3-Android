package com.etheller.warsmash.util;

/** Chooses display callbacks at a fixed rate without accumulating catch-up frames after a stall. */
public final class FrameCadence {
	private final long intervalNanos;
	private long nextFrameNanos = Long.MIN_VALUE;

	public FrameCadence(final int framesPerSecond) {
		if (framesPerSecond <= 0) {
			throw new IllegalArgumentException("Frame rate must be positive");
		}
		this.intervalNanos = 1000000000L / framesPerSecond;
	}

	public boolean shouldRender(final long frameTimeNanos) {
		if (this.nextFrameNanos == Long.MIN_VALUE) {
			this.nextFrameNanos = frameTimeNanos + this.intervalNanos;
			return true;
		}
		// Display timestamps can differ from the nominal interval by a fraction of a millisecond.
		if ((frameTimeNanos + 500000L) < this.nextFrameNanos) {
			return false;
		}
		this.nextFrameNanos += this.intervalNanos;
		if (this.nextFrameNanos <= frameTimeNanos) {
			this.nextFrameNanos = frameTimeNanos + this.intervalNanos;
		}
		return true;
	}

	public void reset() {
		this.nextFrameNanos = Long.MIN_VALUE;
	}
}
