package com.etheller.warsmash.input.touch;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;

/**
 * Maps touch gestures to RTS controls: tapping a friendly unit selects it; tapping terrain, enemies or a worker's
 * building target orders the selection. A one-finger drag pans the camera, and holding then dragging draws a
 * selection box. A held tap always selects a unit. Two fingers rotate, pan or pinch to zoom.
 * Interface taps and pen input keep their normal left-click meaning. On an interface button a long press shows the tooltip, and on
 * a button with autocast it is the right click that toggles it. A two finger tap cancels targeting and clears selection.
 * <p>
 * A tap confirms an active command's target. A building ghost is moved by tapping and confirmed by tapping it again;
 * its map position stays fixed while the camera moves. A pen can still drag to aim an active command. Inventory
 * drags, sliders, minimap navigation and control groups retain their own interactions.
 */
public final class RtsTouchAdapter implements GestureListener {
	private static final String LOG_TAG = "WarsmashTouch";
	private final TouchSettings settings;
	private final boolean debugLog;
	private static final int SHIFT_SLOT = 10;
	private boolean aiming;
	private boolean overlayDrag;
	private boolean itemDrag;
	private boolean selecting;
	private boolean cameraDragging;
	private boolean cameraGesture;
	private boolean aimingBuilding;
	private InputProcessor lastTapProcessor;
	private float aimX;
	private float aimY;
	private int aimStartCursorX;
	private int aimStartCursorY;
	private boolean ghostPlaced;
	private float ghostX;
	private float ghostY;
	private final float[] ghostWorld = new float[3];
	private final float[] ghostScreen = new float[2];

	public RtsTouchAdapter(final TouchSettings settings, final boolean debugLog) {
		this.settings = settings;
		this.debugLog = debugLog;
	}

	private void putGhost(final TouchTarget target, final float x, final float y) {
		this.ghostX = x;
		this.ghostY = y;
		this.ghostPlaced = true;
		target.screenToWorld(Math.round(x), Math.round(y), this.ghostWorld);
	}

	/** Called once a frame after the gestures of the frame. */
	void update() {
		if (!this.ghostPlaced) {
			return;
		}
		final TouchTarget target = target();
		if ((target == null) || !target.isPlacingBuilding()) {
			this.ghostPlaced = false;
			return;
		}
		if (this.aiming) {
			return;
		}
		target.worldToScreen(this.ghostWorld, this.ghostScreen);
		// Only on a real change: the cursor may rest on a button under a finger in the meantime.
		if ((Math.round(this.ghostScreen[0]) != Math.round(this.ghostX))
				|| (Math.round(this.ghostScreen[1]) != Math.round(this.ghostY))) {
			this.ghostX = this.ghostScreen[0];
			this.ghostY = this.ghostScreen[1];
			moveTo(processor(), this.ghostX, this.ghostY);
		}
	}

	private void aimAt(final InputProcessor processor, final float x, final float y) {
		this.aimX = x;
		this.aimY = this.aimingBuilding ? Math.max(0, y - this.settings.buildAimOffsetPx) : y;
		moveTo(processor, this.aimX, this.aimY);
	}

	private static InputProcessor processor() {
		return Gdx.input.getInputProcessor();
	}

	private static TouchTarget target() {
		final InputProcessor processor = processor();
		return processor instanceof TouchTarget ? (TouchTarget) processor : null;
	}

	private static void moveTo(final InputProcessor processor, final float x, final float y) {
		VirtualCursor.moveTo(Math.round(x), Math.round(y));
		processor.mouseMoved(Math.round(x), Math.round(y));
	}

	private static void click(final InputProcessor processor, final float x, final float y, final int button) {
		processor.touchDown(Math.round(x), Math.round(y), 0, button);
		processor.touchUp(Math.round(x), Math.round(y), 0, button);
	}

	@Override
	public void pointerAt(final float x, final float y) {
		final InputProcessor processor = processor();
		final TouchTarget target = target();
		// The finger may still become a two finger pan, so the ghost waits for a tap or a drag before it moves.
		if ((target != null) && VirtualCursor.isFingerInput() && target.isPlacingBuilding()
				&& !target.isOverClickableUi(Math.round(x), Math.round(y))) {
			return;
		}
		if (processor != null) {
			moveTo(processor, x, y);
		}
	}

	@Override
	public void tap(final float x, final float y, final boolean pen) {
		final InputProcessor processor = processor();
		this.lastTapProcessor = null;
		final TouchTarget target = target();
		final int slot = (target == null) ? -1 : target.touchOverlaySlotAt(Math.round(x), Math.round(y));
		if (slot == SHIFT_SLOT) {
			return;
		}
		if (slot >= 0) {
			target.selectControlGroupSlot(slot);
			log("select group slot " + slot);
			return;
		}
		if ((processor != null) && (target != null) && target.isPlacingBuilding()
				&& !target.isOverClickableUi(Math.round(x), Math.round(y))) {
			if (this.ghostPlaced
					&& (Math.hypot(x - this.ghostX, y - this.ghostY) <= this.settings.ghostTapRadiusPx)) {
				moveTo(processor, this.ghostX, this.ghostY);
				click(processor, this.ghostX, this.ghostY, Input.Buttons.LEFT);
				this.ghostPlaced = target.isPlacingBuilding();
				log("tap on ghost -> build" + (this.ghostPlaced ? " refused, ghost kept" : ""));
			}
			else {
				moveTo(processor, x, y);
				putGhost(target, x, y);
				log("ghost moved to " + (int) x + "," + (int) y);
			}
			return;
		}
		this.ghostPlaced = false;
		if (processor != null) {
			moveTo(processor, x, y);
			final boolean worldTap = !pen && (target != null)
					&& target.isWorldInputAt(Math.round(x), Math.round(y)) && !target.hasActiveCommand();
			if (worldTap && target.selectUnitAt(Math.round(x), Math.round(y))) {
				this.lastTapProcessor = processor;
				log("tap -> select friendly unit");
			}
			else {
				final boolean order = worldTap && target.hasControllableSelection();
				click(processor, x, y, order ? Input.Buttons.RIGHT : Input.Buttons.LEFT);
			}
			log("tap " + (int) x + "," + (int) y);
			if ((target != null) && !pen) {
				target.endTouchHover();
			}
		}
	}

	@Override
	public void doubleTap(final float x, final float y, final boolean pen) {
		final TouchTarget target = target();
		if (!pen && (processor() == this.lastTapProcessor) && (target != null) && !target.hasActiveCommand()
				&& target.isWorldInputAt(Math.round(x), Math.round(y))
				&& target.selectUnitsOfSameType(Math.round(x), Math.round(y))) {
			this.ghostPlaced = false;
			this.lastTapProcessor = null;
			target.endTouchHover();
			log("double tap -> select building or matching units");
			return;
		}
		tap(x, y, pen);
	}

	@Override
	public void secondaryTap(final float x, final float y) {
		final InputProcessor processor = processor();
		if (processor != null) {
			moveTo(processor, x, y);
			click(processor, x, y, Input.Buttons.RIGHT);
			log("pen button tap " + (int) x + "," + (int) y + " -> right click");
		}
	}

	@Override
	public void longPress(final float x, final float y) {
		final InputProcessor processor = processor();
		if (processor == null) {
			return;
		}
		if ((processor instanceof SliderHost) && ((SliderHost) processor).isOverSlider(Math.round(x), Math.round(y))) {
			moveTo(processor, x, y);
			return;
		}
		final TouchTarget target = target();
		if ((target != null) && target.skipCinematic()) {
			log("long press -> skip cinematic");
			return;
		}
		moveTo(processor, x, y);
		final int slot = (target == null) ? -1 : target.touchOverlaySlotAt(Math.round(x), Math.round(y));
		if ((slot >= 0) && (slot != SHIFT_SLOT)) {
			target.assignControlGroupSlot(slot, VirtualModifiers.isShiftDown());
			log("assign group slot " + slot);
			return;
		}
		if (slot == SHIFT_SLOT) {
			return;
		}
		if ((target != null) && target.isOverAutocastButton(Math.round(x), Math.round(y))) {
			click(processor, x, y, Input.Buttons.RIGHT);
			log("long press on autocast button -> right click");
			return;
		}
		if ((target != null) && target.isOverClickableUi(Math.round(x), Math.round(y))) {
			log("long press on interface: tooltip only");
			return;
		}
		if ((target != null) && target.isWorldInputAt(Math.round(x), Math.round(y))) {
			if (target.hasActiveCommand()) {
				click(processor, x, y, Input.Buttons.RIGHT);
				this.ghostPlaced = false;
			}
			this.selecting = true;
			processor.touchDown(Math.round(x), Math.round(y), 0, Input.Buttons.LEFT);
			log("hold -> selection start");
		}
	}

	@Override
	public boolean canDragAfterLongPress(final float x, final float y) {
		final InputProcessor processor = processor();
		return this.selecting || ((processor instanceof SliderHost)
				&& ((SliderHost) processor).isOverSlider(Math.round(x), Math.round(y)));
	}

	@Override
	public boolean canStartTwoFingerGesture() {
		return this.cameraDragging || this.selecting;
	}

	@Override
	public void longPressEnd(final float x, final float y) {
		if (this.selecting) {
			dragEnd(x, y);
		}
		final TouchTarget target = target();
		if (target != null) {
			target.endTouchHover();
		}
	}

	@Override
	public void holdTap(final float heldX, final float heldY) {
		final InputProcessor processor = processor();
		final TouchTarget target = target();
		// The hold itself has already toggled autocast; a second right click would only undo it.
		if ((processor != null) && (target != null)
				&& target.isOverClickableUi(Math.round(heldX), Math.round(heldY))
				&& !target.isOverAutocastButton(Math.round(heldX), Math.round(heldY))) {
			click(processor, heldX, heldY, Input.Buttons.RIGHT);
			log("hold and tap -> right click on button (item pick up)");
		}
	}

	@Override
	public void dragStart(final float x, final float y, final boolean pen) {
		final InputProcessor processor = processor();
		final TouchTarget target = target();
		if (this.selecting) {
			return;
		}
		if ((target != null) && (target.touchOverlaySlotAt(Math.round(x), Math.round(y)) >= 0)) {
			this.overlayDrag = true;
			return;
		}
		if ((processor != null) && (target != null) && target.isOverInventorySlot(Math.round(x), Math.round(y))) {
			moveTo(processor, x, y);
			click(processor, x, y, Input.Buttons.RIGHT);
			this.itemDrag = true;
			log("item picked up from slot");
			return;
		}
		if (!pen && (target != null) && target.isWorldInputAt(Math.round(x), Math.round(y))) {
			this.cameraDragging = true;
			panStart(x, y);
			return;
		}
		if ((processor != null) && (target != null) && target.hasActiveCommand()
				&& target.isWorldInputAt(Math.round(x), Math.round(y))) {
			this.aiming = true;
			this.aimingBuilding = target.isPlacingBuilding() && !pen;
			this.aimStartCursorX = VirtualCursor.getX();
			this.aimStartCursorY = VirtualCursor.getY();
			aimAt(processor, x, y);
			log("aim start" + (this.aimingBuilding ? " (building)" : ""));
			return;
		}
		if (processor != null) {
			moveTo(processor, x, y);
			processor.touchDown(Math.round(x), Math.round(y), 0, Input.Buttons.LEFT);
			log("drag start " + (int) x + "," + (int) y);
		}
	}

	@Override
	public void drag(final float x, final float y) {
		if (this.cameraDragging) {
			pan(x, y);
			return;
		}
		if (this.overlayDrag) {
			return;
		}
		final InputProcessor processor = processor();
		if ((processor != null) && (this.aiming || this.itemDrag)) {
			if (this.itemDrag) {
				moveTo(processor, x, y);
			}
			else {
				aimAt(processor, x, y);
			}
			return;
		}
		if (processor != null) {
			VirtualCursor.moveTo(Math.round(x), Math.round(y));
			processor.touchDragged(Math.round(x), Math.round(y), 0);
		}
	}

	@Override
	public void dragEnd(final float x, final float y) {
		if (this.cameraDragging) {
			this.cameraDragging = false;
			panEnd(x, y);
			return;
		}
		final boolean wasSelecting = this.selecting;
		this.selecting = false;
		if (this.overlayDrag) {
			this.overlayDrag = false;
			return;
		}
		final InputProcessor processor = processor();
		if ((processor != null) && this.itemDrag) {
			this.itemDrag = false;
			moveTo(processor, x, y);
			final TouchTarget target = target();
			final boolean onSlot = (target != null) && target.isOverInventorySlot(Math.round(x), Math.round(y));
			// A right click on a slot moves the carried item there; a left click elsewhere drops or gives it.
			click(processor, x, y, onSlot ? Input.Buttons.RIGHT : Input.Buttons.LEFT);
			log("item released " + (onSlot ? "on a slot" : "in the world"));
			return;
		}
		if ((processor != null) && this.aiming) {
			this.aiming = false;
			aimAt(processor, x, y);
			final TouchTarget target = target();
			if ((target != null) && target.isPlacingBuilding()) {
				putGhost(target, this.aimX, this.aimY);
				log("ghost placed at " + (int) this.aimX + "," + (int) this.aimY);
			}
			else {
				click(processor, this.aimX, this.aimY, Input.Buttons.LEFT);
				log("aim release -> cast at " + (int) this.aimX + "," + (int) this.aimY);
			}
			return;
		}
		if (processor != null) {
			if (wasSelecting) {
				// A synthetic hover here used to clear the box preview immediately before release.
				VirtualCursor.moveTo(Math.round(x), Math.round(y));
			}
			else {
				moveTo(processor, x, y);
			}
			processor.touchUp(Math.round(x), Math.round(y), 0, Input.Buttons.LEFT);
			log("drag end " + (int) x + "," + (int) y);
		}
	}

	@Override
	public void panStart(final float x, final float y) {
		final InputProcessor processor = processor();
		final TouchTarget target = target();
		this.cameraGesture = (target == null) || target.isWorldInputAt(Math.round(x), Math.round(y));
		if ((processor != null) && this.cameraGesture) {
			processor.touchDown(Math.round(x), Math.round(y), 0, Input.Buttons.MIDDLE);
			log("pan start");
		}
	}

	@Override
	public void pan(final float x, final float y) {
		final InputProcessor processor = processor();
		if ((processor != null) && this.cameraGesture) {
			processor.touchDragged(Math.round(x), Math.round(y), 0);
		}
	}

	@Override
	public void panEnd(final float x, final float y) {
		final InputProcessor processor = processor();
		if ((processor != null) && this.cameraGesture) {
			processor.touchUp(Math.round(x), Math.round(y), 0, Input.Buttons.MIDDLE);
			log("pan end");
		}
		this.cameraGesture = false;
	}

	@Override
	public void rotate(final float centerX, final float centerY, final float degrees) {
		final TouchTarget target = target();
		if ((target != null) && target.isWorldInputAt(Math.round(centerX), Math.round(centerY))
				&& Float.isFinite(degrees)) {
			target.rotateCamera(degrees);
		}
	}

	@Override
	public void zoomStep(final int direction) {
		if (!this.cameraGesture) {
			return;
		}
		final InputProcessor processor = processor();
		final TouchTarget target = target();
		if ((target != null) && target.zoomCamera(direction)) {
			return;
		}
		if (processor != null) {
			processor.scrolled(0, -direction);
			log("zoom " + direction);
		}
	}

	@Override
	public void twoFingerTap(final float x, final float y) {
		final TouchTarget target = target();
		if ((target != null) && target.isWorldInputAt(Math.round(x), Math.round(y))) {
			this.ghostPlaced = false;
			this.lastTapProcessor = null;
			target.clearTouchSelection();
			target.endTouchHover();
			log("two finger tap -> clear selection");
		}
	}

	@Override
	public void cancel() {
		this.lastTapProcessor = null;
		final InputProcessor processor = processor();
		if ((processor != null) && this.aiming && this.aimingBuilding) {
			// A second finger turned the drag into a pan, so the ghost goes back to where it was before the drag.
			moveTo(processor, this.aimStartCursorX, this.aimStartCursorY);
		}
		this.aiming = false;
		this.itemDrag = false;
		this.overlayDrag = false;
		this.selecting = false;
		this.cameraDragging = false;
		this.cameraGesture = false;
		final TouchTarget target = target();
		if (target != null) {
			target.cancelPointerDrag();
		}
		log("cancel");
	}

	private void log(final String message) {
		if (this.debugLog) {
			Gdx.app.log(LOG_TAG, message);
		}
	}
}
