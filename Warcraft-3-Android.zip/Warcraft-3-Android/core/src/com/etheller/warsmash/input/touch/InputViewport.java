package com.etheller.warsmash.input.touch;

import com.badlogic.gdx.Gdx;

/** Physical game-view pixels to render pixels. Native Android overlays keep their original coordinates. */
public final class InputViewport {
	/** Both dimensions are published together from the Android layout thread. Zero uses native coordinates. */
	private static volatile long inputSize;

	private InputViewport() {
	}

	public static void setInputSize(final int width, final int height) {
		inputSize = (width > 0) && (height > 0) ? ((long) width << 32) | (height & 0xFFFFFFFFL) : 0;
	}

	public static float scaleX() {
		return scale((int) (inputSize >>> 32), Gdx.graphics == null ? 0 : Gdx.graphics.getWidth());
	}

	public static float scaleY() {
		return scale((int) inputSize, Gdx.graphics == null ? 0 : Gdx.graphics.getHeight());
	}

	private static float scale(final int physical, final int rendered) {
		return (physical > 0) && (rendered > 0) ? (float) rendered / physical : 1;
	}

	/** A dp tolerance must shrink with the rendered image to retain its physical touch size. */
	public static float density() {
		return (Gdx.graphics == null ? 1 : Gdx.graphics.getDensity()) * Math.min(scaleX(), scaleY());
	}
}
