package com.etheller.warsmash.input.touch;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.LongSupplier;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;

/**
 * Takes pointer events from a platform source on its own thread and replays them on the render thread: touches go
 * through the gesture recognizer to the RTS adapter, pen hover and wheel go straight to whichever screen currently
 * owns libGDX input.
 */
public final class TouchInputRouter {
	private static final String LOG_TAG = "WarsmashTouch";
	private static final int SHIFT_SLOT = 10;
	private static volatile TouchInputRouter installed;
	private int shiftPointerId = -1;

	private final Queue<PointerEvent> events = new ConcurrentLinkedQueue<>();
	private final TouchSettings physicalSettings;
	private GestureRecognizer recognizer;
	private PalmFilter palmFilter;
	private final LongSupplier clock;
	private final boolean debugLog;
	private RtsTouchAdapter adapter;
	private float scaleX = 1;
	private float scaleY = 1;
	private boolean drained;

	/**
	 * @param clock the time base of the events, for example Android uptime
	 */
	public TouchInputRouter(final TouchSettings settings, final LongSupplier clock, final boolean debugLog) {
		this.physicalSettings = settings;
		this.clock = clock;
		this.debugLog = debugLog;
		configure(settings);
	}

	private void configure(final TouchSettings settings) {
		this.adapter = new RtsTouchAdapter(settings, this.debugLog);
		this.recognizer = new GestureRecognizer(settings, this.adapter);
		this.palmFilter = new PalmFilter(settings.palmTouchMajorPx, settings.penFingerPolicy);
	}

	public static void install(final TouchInputRouter router) {
		installed = router;
		VirtualCursor.setTouchDevice(router != null);
	}

	public static boolean isActive() {
		return installed != null;
	}

	public static void drainInstalled() {
		final TouchInputRouter router = installed;
		if (router != null) {
			router.drain();
		}
	}

	public void post(final PointerEvent event) {
		this.events.add(event);
	}

	public void cancel() {
		post(new PointerEvent(-1, PointerEvent.Tool.FINGER, PointerEvent.Action.CANCEL, 0, 0, 0, 0, 0, 0,
				this.clock.getAsLong()));
	}

	public void drain() {
		// Read the buffer dimensions on the GL thread, after the backend has applied surfaceChanged.
		// Android queues physical coordinates, so pointer events never use a stale buffer size.
		final float nextScaleX = InputViewport.scaleX();
		final float nextScaleY = InputViewport.scaleY();
		if ((nextScaleX != this.scaleX) || (nextScaleY != this.scaleY)) {
			if (this.drained) {
				dispatch(new PointerEvent(-1, PointerEvent.Tool.FINGER, PointerEvent.Action.CANCEL, 0, 0,
						0, 0, 0, 0, this.clock.getAsLong()));
				// A resize abandons gestures and events belonging to the old viewport, including held Shift.
				this.events.clear();
			}
			this.scaleX = nextScaleX;
			this.scaleY = nextScaleY;
			configure(this.physicalSettings.scaled(Math.min(this.scaleX, this.scaleY)));
		}
		PointerEvent event;
		while ((event = this.events.poll()) != null) {
			if ((this.scaleX != 1) || (this.scaleY != 1)) {
				event = new PointerEvent(event.pointerId, event.tool, event.action, event.x * this.scaleX,
						event.y * this.scaleY, event.buttons, event.pressure,
						event.touchMajor * Math.min(this.scaleX, this.scaleY), event.scroll, event.timeMillis);
			}
			dispatch(event);
		}
		this.recognizer.update(this.clock.getAsLong());
		this.adapter.update();
		this.drained = true;
	}

	/**
	 * A finger that lands on the on-screen Shift holds it until it lifts and never reaches gesture recognition, so the
	 * other fingers keep giving ordinary taps and drags meanwhile.
	 */
	private boolean handleShiftPointer(final PointerEvent event, final InputProcessor processor) {
		if (event.pointerId == this.shiftPointerId) {
			if ((event.action == PointerEvent.Action.UP) || (event.action == PointerEvent.Action.CANCEL)) {
				this.shiftPointerId = -1;
				VirtualModifiers.setShiftHeld(false);
				if (this.debugLog) {
					Gdx.app.log(LOG_TAG, "shift released");
				}
			}
			return true;
		}
		if ((event.action == PointerEvent.Action.DOWN) && (this.shiftPointerId == -1)
				&& (processor instanceof TouchTarget) && (((TouchTarget) processor)
						.touchOverlaySlotAt(Math.round(event.x), Math.round(event.y)) == SHIFT_SLOT)) {
			this.shiftPointerId = event.pointerId;
			VirtualModifiers.setShiftHeld(true);
			if (this.debugLog) {
				Gdx.app.log(LOG_TAG, "shift held");
			}
			return true;
		}
		return false;
	}

	private void dispatch(final PointerEvent event) {
		if (event.action == PointerEvent.Action.CANCEL) {
			this.shiftPointerId = -1;
			VirtualModifiers.setShiftHeld(false);
			this.palmFilter.reset();
			this.recognizer.onEvent(event);
			return;
		}
		if (!this.palmFilter.accept(event)) {
			if (this.debugLog && (event.action == PointerEvent.Action.DOWN)) {
				Gdx.app.log(LOG_TAG, "dropped as palm or finger near pen: " + event);
			}
			return;
		}
		if ((event.action == PointerEvent.Action.DOWN) || (event.action == PointerEvent.Action.HOVER_MOVE)) {
			VirtualCursor.setFingerInput(event.tool == PointerEvent.Tool.FINGER);
		}
		final InputProcessor processor = Gdx.input.getInputProcessor();
		switch (event.action) {
		case HOVER_MOVE:
			if (processor != null) {
				VirtualCursor.moveTo(Math.round(event.x), Math.round(event.y));
				processor.mouseMoved(Math.round(event.x), Math.round(event.y));
			}
			break;
		case HOVER_EXIT:
			if (processor != null) {
				// Far outside the screen, so unit highlights and tooltips under the pen go away.
				processor.mouseMoved(-100000, -100000);
			}
			break;
		case SCROLL:
			if (processor != null) {
				processor.scrolled(0, event.scroll);
			}
			break;
		default:
			if (handleShiftPointer(event, processor)) {
				break;
			}
			if (this.debugLog && (event.action != PointerEvent.Action.MOVE)) {
				Gdx.app.log(LOG_TAG, event.toString());
			}
			this.recognizer.onEvent(event);
			break;
		}
	}
}
