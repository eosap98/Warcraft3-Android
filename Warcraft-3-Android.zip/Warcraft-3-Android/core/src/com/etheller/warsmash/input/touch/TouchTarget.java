package com.etheller.warsmash.input.touch;

/**
 * What the touch adapter needs to know about a screen beyond plain mouse input, so that gestures which mean different
 * things in different places do the right thing. Screens that do not implement it get plain mouse synthesis.
 */
public interface TouchTarget {
	/** Whether a button or other clickable interface frame is under the point, in screen pixels. */
	boolean isOverClickableUi(int screenX, int screenY);

	boolean isOverInventorySlot(int screenX, int screenY);

	/** Whether a command button with autocast is under the point, in screen pixels. */
	boolean isOverAutocastButton(int screenX, int screenY);

	boolean hasActiveCommand();

	/** The map accepts camera gestures and orders here, outside the minimap and interface windows. */
	default boolean isWorldInputAt(final int screenX, final int screenY) {
		return !isOverClickableUi(screenX, screenY);
	}

	/** At least one selected unit belongs to the player or can be controlled through an alliance. */
	default boolean hasControllableSelection() {
		return false;
	}

	/** Select a friendly unit, unless a selected worker can work on the touched building. */
	default boolean selectUnitAt(final int screenX, final int screenY) {
		return false;
	}

	/** Select visible units matching the same friendly unit as the first tap; buildings stay exclusive. */
	default boolean selectUnitsOfSameType(final int screenX, final int screenY) {
		return false;
	}

	/** Cancel targeting and clear the player's selection, without issuing a unit order. */
	default void clearTouchSelection() {
	}

	default void rotateCamera(final float degrees) {
	}

	/** @return true when the target handled a pinch zoom itself. */
	default boolean zoomCamera(final int direction) {
		return false;
	}

	/** Whether the active command shows a building ghost to place. */
	boolean isPlacingBuilding();

	/** Writes the map point under the screen point (x, y, z) to out. */
	void screenToWorld(int screenX, int screenY, float[] out);

	/** Writes the screen point of the map point to out (x, y); it may lie outside the screen. */
	void worldToScreen(float[] world, float[] out);

	/**
	 * @return the touch overlay slot under the point: 0 to 9 for control groups, 10 for Shift, 11 for the plus button, -1 for none
	 */
	int touchOverlaySlotAt(int screenX, int screenY);

	void selectControlGroupSlot(int slot);

	void assignControlGroupSlot(int slot, boolean add);

	/** Abandon a press in progress without performing it, for example a selection box. */
	void cancelPointerDrag();

	/**
	 * The finger has left the screen: a pointer no longer rests over the interface, so hover state and its tooltip
	 * end. A tooltip is shown only while a finger is held on a button.
	 */
	void endTouchHover();

	/**
	 * A one finger long press skips a cinematic on a touch screen, as Escape does on desktop.
	 *
	 * @return true if cinematic mode is on and the skip was sent
	 */
	boolean skipCinematic();
}
