package com.etheller.warsmash.localization;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import com.google.gson.Gson;

/**
 * Translations of descriptive text from the supplied Warcraft III 1.31 data. Lookups are made at display boundaries,
 * before tooltip parameters are expanded. Map/quest titles, hero names and script data are left intact.
 */
public final class IndonesianContent {
	private static final Pattern LINES = Pattern.compile("\\|[nN]|\\r?\\n");
	private static final Pattern COLORS = Pattern.compile("\\|[cC][0-9a-fA-F]{8}|\\|[rR]");
	private static final Pattern DECORATED = Pattern.compile("^(\\|[cC][0-9a-fA-F]{8})(.*)(\\|[rR])$", Pattern.DOTALL);
	private static final Pattern NUMBERS = Pattern.compile("\\|[cC][0-9a-fA-F]{8}|<[^<>\\r\\n]+>"
			+ "|%(?:\\d+\\$)?[-+0#\\d.]*[a-zA-Z%](?![a-zA-Z])|(\\d+(?:[.,]\\d+)*)");
	private static final Pattern NUMBER_SLOT = Pattern.compile("\\$\\{(\\d+)\\}");

	private IndonesianContent() {
	}

	private static final class Data {
		Map<String, String> text;
		Map<String, String> glue;
		Map<String, String> numbers;
		Set<String> protectedNames;
	}

	private static final class Holder {
		static final Data DATA = read();
	}

	private static Data read() {
		try (InputStream in = IndonesianContent.class.getResourceAsStream("indonesian-content.json.gz")) {
			if (in == null) {
				throw new IllegalStateException("Missing Indonesian game text dictionary");
			}
			try (InputStreamReader reader = new InputStreamReader(new GZIPInputStream(in), StandardCharsets.UTF_8)) {
				final Data data = new Gson().fromJson(reader, Data.class);
				if ((data == null) || (data.text == null) || (data.glue == null) || (data.protectedNames == null)) {
					throw new IllegalStateException("Incomplete Indonesian game text dictionary");
				}
				data.text = Collections.unmodifiableMap(data.text);
				data.glue = Collections.unmodifiableMap(data.glue);
				data.numbers = data.numbers == null ? Collections.emptyMap() : Collections.unmodifiableMap(data.numbers);
				data.protectedNames = Collections.unmodifiableSet(new HashSet<>(data.protectedNames));
				return data;
			}
		}
		catch (final IOException e) {
			throw new IllegalStateException("Unable to read Indonesian game text dictionary", e);
		}
	}

	static Map<String, String> glueStrings() {
		return Holder.DATA.glue;
	}

	/** Used by the native Android launcher, before Gdx exists. */
	public static String get(final String original) {
		if ((original == null) || original.isEmpty() || isProtectedName(original)) {
			return original;
		}
		final String translated = lookup(original);
		if (translated != null) {
			return translated;
		}
		// Scripts sometimes concatenate independently translated messages with line breaks.
		final Matcher lines = LINES.matcher(original);
		final StringBuilder result = new StringBuilder();
		int start = 0;
		while (lines.find()) {
			final String part = original.substring(start, lines.start());
			final String line = lookup(part);
			result.append(line == null ? part : line).append(lines.group());
			start = lines.end();
		}
		if (start == 0) {
			return original;
		}
		final String part = original.substring(start);
		final String line = lookup(part);
		return result.append(line == null ? part : line).toString();
	}

	private static String lookup(final String original) {
		final String exact = Holder.DATA.text.get(original);
		if (exact != null) {
			return exact;
		}
		final String trimmed = original.trim();
		String translated = Holder.DATA.text.get(trimmed);
		if (translated == null) {
			translated = numberedText(trimmed);
		}
		if (translated == null) {
			final Matcher decorated = DECORATED.matcher(trimmed);
			if (decorated.matches()) {
				final String inner = decorated.group(2);
				String value = Holder.DATA.text.get(inner);
				if (value == null) {
					value = numberedText(inner);
				}
				if (value != null) {
					translated = decorated.group(1) + value + decorated.group(3);
				}
			}
		}
		if (translated == null) {
			return null;
		}
		final int start = original.indexOf(trimmed);
		return original.substring(0, start) + translated + original.substring(start + trimmed.length());
	}

	/** Known counter sentences can contain numbers filled in by a map script after the WTS lookup. */
	private static String numberedText(final String original) {
		if (Holder.DATA.numbers.isEmpty()) {
			return null;
		}
		final Matcher numbers = NUMBERS.matcher(original);
		final StringBuffer key = new StringBuffer();
		final List<String> values = new ArrayList<>();
		while (numbers.find()) {
			if (numbers.group(1) != null) {
				numbers.appendReplacement(key, Matcher.quoteReplacement("${" + values.size() + "}"));
				values.add(numbers.group(1));
			}
		}
		if (values.isEmpty()) {
			return null;
		}
		numbers.appendTail(key);
		final String template = Holder.DATA.numbers.get(key.toString());
		if (template == null) {
			return null;
		}
		final Matcher slots = NUMBER_SLOT.matcher(template);
		final StringBuffer result = new StringBuffer();
		while (slots.find()) {
			final int index = Integer.parseInt(slots.group(1));
			if (index >= values.size()) {
				return null;
			}
			slots.appendReplacement(result, Matcher.quoteReplacement(values.get(index)));
		}
		return slots.appendTail(result).toString();
	}

	public static String text(final String original) {
		return IndonesianUi.isEnabled() ? get(original) : original;
	}

	public static String unitName(final String original, final boolean hero) {
		return hero ? original : text(original);
	}

	public static boolean isProtectedName(final String original) {
		return original != null && Holder.DATA.protectedNames.contains(
				original.indexOf('|') < 0 ? original.trim() : COLORS.matcher(original).replaceAll("").trim());
	}
}
