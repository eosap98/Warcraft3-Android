package com.etheller.warsmash.localization;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import com.badlogic.gdx.Application.ApplicationType;
import com.badlogic.gdx.Gdx;

/** Android interface translations by UI key; map strings, mission titles and hero names are never rewritten. */
public final class IndonesianUi {
	private static final Properties STRINGS = read();
	private static final Map<String, String> GLUE = glueStrings();

	private IndonesianUi() {
	}

	private static Properties read() {
		final Properties strings = new Properties();
		try (InputStream in = IndonesianUi.class.getResourceAsStream("indonesian.properties")) {
			if (in == null) {
				throw new IllegalStateException("Missing Indonesian interface translations");
			}
			strings.load(new InputStreamReader(in, StandardCharsets.UTF_8));
		}
		catch (final IOException e) {
			throw new IllegalStateException("Unable to read Indonesian interface translations", e);
		}
		return strings;
	}

	private static Map<String, String> glueStrings() {
		final Map<String, String> strings = new HashMap<>(IndonesianContent.glueStrings());
		for (final String key : STRINGS.stringPropertyNames()) {
			if (key.startsWith("glue.")) {
				strings.put(key.substring(5), STRINGS.getProperty(key));
			}
		}
		return Collections.unmodifiableMap(strings);
	}

	public static boolean isEnabled() {
		return (Gdx.app != null) && (Gdx.app.getType() == ApplicationType.Android);
	}

	/** Used by native Android launcher pages even before the engine creates its Gdx application. */
	public static String glue(final String key, final String fallback) {
		return key == null ? fallback : GLUE.getOrDefault(key.toUpperCase(Locale.ROOT), fallback);
	}

	public static Map<String, String> templateStrings() {
		return GLUE;
	}

	public static String get(final String key, final String fallback) {
		return STRINGS.getProperty(key, fallback);
	}

	public static String text(final String key, final String fallback) {
		return isEnabled() ? get(key, fallback) : fallback;
	}

	/** Only known static interface frames; arbitrary names and map-created text are not translated. */
	public static String frameText(final String name, final String buttonName, final String fallback) {
		final String translated = name == null ? null : STRINGS.getProperty("frame." + name);
		if (translated != null) {
			return translated;
		}
		return buttonName == null ? fallback : STRINGS.getProperty("frame." + buttonName, fallback);
	}

	public static String error(final String key) {
		return key == null ? null : STRINGS.getProperty("error." + key.toLowerCase(Locale.ROOT));
	}

	public static List<String> tips() {
		final List<String> tips = new ArrayList<>();
		for (int i = 1; STRINGS.containsKey("tip." + i); i++) {
			tips.add(STRINGS.getProperty("tip." + i));
		}
		return tips;
	}
}
