package com.etheller.warsmash.networking.lan;

import com.etheller.warsmash.parsers.jass.scope.CommonTriggerExecutionScope;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.CSimulation;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayer;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerUnitOrderExecutor;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.trigger.JassGameEventsWar3;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.trigger.enumtypes.CPlayerSlotState;

/** A departing LAN player must run the melee leave trigger on every remaining simulation. */
final class LanPlayerOrderExecutor extends CPlayerUnitOrderExecutor {
	private final CSimulation simulation;
	private final int playerIndex;

	LanPlayerOrderExecutor(final CSimulation simulation, final int playerIndex) {
		super(simulation, playerIndex);
		this.simulation = simulation;
		this.playerIndex = playerIndex;
	}

	@Override
	public void leaveGame() {
		final CPlayer player = this.simulation.getPlayer(this.playerIndex);
		final boolean playing = player.getSlotState() == CPlayerSlotState.PLAYING;
		super.leaveGame();
		if (playing) {
			player.firePlayerEvents(CommonTriggerExecutionScope::triggerPlayerScope, JassGameEventsWar3.EVENT_PLAYER_LEAVE);
		}
	}
}
