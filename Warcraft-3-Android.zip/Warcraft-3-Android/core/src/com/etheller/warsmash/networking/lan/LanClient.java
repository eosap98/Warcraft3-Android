package com.etheller.warsmash.networking.lan;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;

/** One player's connection, retained while Android changes from the lobby activity to the game activity. */
public final class LanClient implements AutoCloseable, LanConnection.Listener {
	private final LanConnection connection;
	private final ArrayBlockingQueue<LanProtocol.Message> turns = new ArrayBlockingQueue<>(4);
	private final String engineVersion;
	private volatile LanLobby lobby;
	private volatile int player = -1;
	private volatile String error;
	private volatile Runnable listener;
	private volatile boolean finished;
	private volatile boolean running;
	private volatile long lastTurn = System.nanoTime();
	private int nextTurn;

	public static LanClient connect(final InetSocketAddress address, final String version, final String name,
			final String hostKey) throws IOException {
		final Socket socket = new Socket();
		try {
			socket.connect(address, 6000);
			return new LanClient(socket, version, name, hostKey);
		}
		catch (final IOException | RuntimeException e) {
			socket.close();
			throw e;
		}
	}

	private LanClient(final Socket socket, final String version, final String name, final String hostKey)
			throws IOException {
		this.engineVersion = version;
		this.connection = new LanConnection(socket, this);
		final LanProtocol.Message hello = new LanProtocol.Message("hello");
		hello.protocol = LanProtocol.VERSION;
		hello.version = version;
		hello.name = name;
		hello.hostKey = hostKey;
		this.connection.send(hello);
		this.connection.start();
	}

	public void setListener(final Runnable listener) {
		this.listener = listener;
		changed();
	}

	private void changed() {
		final Runnable listener = this.listener;
		if (listener != null) {
			listener.run();
		}
	}

	public LanLobby lobby() {
		final LanLobby value = this.lobby;
		return value == null ? null : value.copy();
	}

	public int player() {
		return this.player;
	}

	public String error() {
		return this.error;
	}

	public boolean isRunning() {
		return this.running;
	}

	public boolean isFinished() {
		return this.finished;
	}

	public boolean waitingForTurn() {
		return this.running && !this.finished && System.nanoTime() - this.lastTurn > 3_000_000_000L;
	}

	public void choose(final int race, final int team) {
		final LanProtocol.Message message = new LanProtocol.Message("choice");
		message.race = race;
		message.team = team;
		this.connection.send(message);
	}

	public void ready(final boolean ready, final String mapHash, final int dataChecksum, final String graphics) {
		final LanProtocol.Message message = new LanProtocol.Message("ready");
		message.ready = ready;
		message.mapHash = mapHash;
		message.dataChecksum = dataChecksum;
		message.graphics = graphics;
		this.connection.send(message);
	}

	public void startGame() {
		this.connection.send(new LanProtocol.Message("start"));
	}

	void loaded(final int checksum) {
		final LanProtocol.Message message = new LanProtocol.Message("loaded");
		message.checksum = checksum;
		this.connection.send(message);
	}

	void input(final int turn, final byte[] commands, final int checksum) {
		if (this.finished || this.error != null) {
			return;
		}
		try {
			LanCommands.validate(commands);
		}
		catch (final IllegalArgumentException e) {
			abort(e.getMessage());
			return;
		}
		final LanProtocol.Message message = new LanProtocol.Message("input");
		message.turn = turn;
		message.commands = commands;
		message.checksum = checksum;
		this.connection.send(message);
	}

	LanProtocol.Message pollTurn() {
		return this.turns.poll();
	}

	public void retire() {
		if (!this.finished) {
			this.finished = true;
			this.connection.send(new LanProtocol.Message("retire"));
			this.turns.clear();
		}
	}

	@Override
	public void received(final LanProtocol.Message message) throws IOException {
		switch (message.type) {
		case "welcome":
			if (this.player >= 0) {
				throw new IOException("Slot LAN sudah ditetapkan.");
			}
			this.player = message.player;
			// fall through: the welcome includes the complete lobby
		case "lobby":
		case "start":
			if (message.lobby == null) {
				throw new IOException("Ruang LAN tidak valid.");
			}
			message.lobby.validate();
			if (!this.engineVersion.equals(message.lobby.engineVersion) || message.lobby.slot(this.player) == null) {
				throw new IOException("Versi atau slot LAN berbeda dengan host.");
			}
			this.lobby = message.lobby;
			changed();
			break;
		case "turn":
			if (this.finished) {
				return;
			}
			if (this.lobby == null || !this.lobby.started || message.turn != this.nextTurn
					|| message.orders == null || message.orders.size() > LanLobby.MAX_PLAYERS) {
				throw new IOException("Urutan perintah dari host tidak valid.");
			}
			final Set<Integer> seen = new HashSet<>();
			for (final LanProtocol.Order order : message.orders) {
				if (order == null || this.lobby.slot(order.player) == null || !seen.add(order.player)) {
					throw new IOException("Pemain dalam perintah LAN tidak valid.");
				}
				LanCommands.validate(order.commands);
			}
			if (!this.turns.offer(message)) {
				throw new IOException("Antrean langkah LAN penuh.");
			}
			this.nextTurn++;
			this.lastTurn = System.nanoTime();
			if (!this.running) {
				this.running = true;
				changed();
			}
			break;
		case "error":
			abort(message.text == null ? "Koneksi LAN terputus." : message.text);
			break;
		default:
			throw new IOException("Pesan host tidak dikenal.");
		}
	}

	public void abort(final String reason) {
		this.connection.fail(reason);
	}

	@Override
	public void closed(final String reason) {
		if (!this.finished) {
			this.error = reason;
			changed();
		}
	}

	@Override
	public void close() {
		this.finished = true;
		this.listener = null;
		this.connection.close();
		this.turns.clear();
	}
}
