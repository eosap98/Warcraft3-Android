package com.etheller.warsmash.networking.lan;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class LanAddresses {
	/** Accept a numeric IPv4 address and optional port, without depending on Internet DNS. */
	public static InetSocketAddress parse(final String text) {
		try {
			final String[] address = text.trim().split(":", -1);
			if (address.length > 2) {
				throw new IllegalArgumentException();
			}
			final String[] parts = address[0].split("\\.", -1);
			if (parts.length != 4) {
				throw new IllegalArgumentException();
			}
			final byte[] bytes = new byte[4];
			for (int i = 0; i < 4; i++) {
				if (!parts[i].matches("[0-9]{1,3}")) {
					throw new IllegalArgumentException();
				}
				final int value = Integer.parseInt(parts[i]);
				if (value > 255) {
					throw new IllegalArgumentException();
				}
				bytes[i] = (byte) value;
			}
			final int port = address.length == 2 ? Integer.parseInt(address[1]) : LanServer.DEFAULT_PORT;
			final InetAddress host = InetAddress.getByAddress(bytes);
			if (port < 1 || port > 65535 || host.isAnyLocalAddress() || host.isMulticastAddress()
					|| (bytes[0] & 255) == 255) {
				throw new IllegalArgumentException();
			}
			return new InetSocketAddress(host, port);
		}
		catch (final RuntimeException | UnknownHostException e) {
			throw new IllegalArgumentException("Masukkan IP host, misalnya 192.168.43.1 atau 192.168.43.1:6112.", e);
		}
	}

	/** Includes Android hotspot interfaces as well as Wi-Fi/Ethernet, excluding cellular and VPN tunnels. */
	public static List<String> local() {
		final List<String> addresses = new ArrayList<>();
		try {
			final java.util.Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			if (interfaces == null) {
				return addresses;
			}
			for (final NetworkInterface network : Collections.list(interfaces)) {
				final String name = network.getName().toLowerCase(Locale.ROOT);
				if (!network.isUp() || network.isLoopback() || name.startsWith("rmnet") || name.startsWith("ccmni")
						|| name.startsWith("pdp") || name.startsWith("tun") || name.startsWith("ppp")) {
					continue;
				}
				for (final InetAddress address : Collections.list(network.getInetAddresses())) {
					if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
						addresses.add(address.getHostAddress());
					}
				}
			}
		}
		catch (final SocketException ignored) {
		}
		Collections.sort(addresses);
		return addresses;
	}

	private LanAddresses() {
	}
}
