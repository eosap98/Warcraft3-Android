package com.etheller.warsmash.networking.lan;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

/** Length-delimited messages over one reliable TCP stream, from lobby through the last game turn. */
final class LanProtocol {
	static final int VERSION = 1;
	static final int PORT = 6112;
	static final int MAX_PACKET = 1024 * 1024;
	static final int MAX_COMMAND_BYTES = 8192;
	static final int CHECKSUM_INTERVAL = 20;
	private static final Gson JSON = new Gson();

	static final class Message {
		String type;
		int protocol;
		String version;
		String name;
		String hostKey;
		String text;
		LanLobby lobby;
		int player;
		int race;
		int team;
		boolean ready;
		String mapHash;
		int dataChecksum;
		String graphics;
		int turn;
		int checksum;
		byte[] commands;
		List<Order> orders;

		Message(final String type) {
			this.type = type;
		}
	}

	static final class Order {
		int player;
		byte[] commands;

		Order(final int player, final byte[] commands) {
			this.player = player;
			this.commands = commands;
		}
	}

	static Message read(final DataInputStream in) throws IOException {
		final int size = in.readInt();
		if (size < 2 || size > MAX_PACKET) {
			throw new IOException("Ukuran paket LAN tidak valid.");
		}
		final byte[] bytes = new byte[size];
		in.readFully(bytes);
		try {
			final Message message = JSON.fromJson(new String(bytes, StandardCharsets.UTF_8), Message.class);
			if (message == null || message.type == null || message.type.length() > 16) {
				throw new IOException("Pesan LAN tidak valid.");
			}
			return message;
		}
		catch (final JsonParseException | IllegalStateException e) {
			throw new IOException("Pesan LAN rusak.", e);
		}
	}

	static void write(final DataOutputStream out, final Message message) throws IOException {
		final byte[] bytes = JSON.toJson(message).getBytes(StandardCharsets.UTF_8);
		if (bytes.length > MAX_PACKET) {
			throw new IOException("Paket LAN terlalu besar.");
		}
		out.writeInt(bytes.length);
		out.write(bytes);
		out.flush();
	}

	private LanProtocol() {
	}
}
