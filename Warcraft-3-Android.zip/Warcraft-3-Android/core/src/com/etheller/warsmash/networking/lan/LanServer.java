package com.etheller.warsmash.networking.lan;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerCommandCodec;

/** An embedded LAN host. Every simulation step waits for the input of every active player. */
public final class LanServer implements AutoCloseable {
	public static final int DEFAULT_PORT = LanProtocol.PORT;
	private final ServerSocket socket;
	private final LanLobby lobby;
	private final String hostKey = UUID.randomUUID().toString();
	private final Set<Peer> connections = new HashSet<>();
	private final Map<Integer, Peer> players = new TreeMap<>();
	private final Map<Integer, LanProtocol.Message> inputs = new TreeMap<>();
	private final Set<Integer> departed = new TreeSet<>();
	private final ScheduledExecutorService watchdog = Executors.newSingleThreadScheduledExecutor(action -> {
		final Thread thread = new Thread(action, "LAN watchdog");
		thread.setDaemon(true);
		return thread;
	});
	private boolean closed;
	private boolean running;
	private int turn;
	private long progress = System.nanoTime();

	public LanServer(final LanLobby lobby, final int port) throws IOException {
		lobby.validate();
		this.lobby = lobby.copy();
		this.lobby.started = false;
		this.lobby.seed = new SecureRandom().nextInt();
		for (final LanLobby.Slot slot : this.lobby.slots) {
			slot.name = "";
			slot.ready = false;
		}
		this.socket = new ServerSocket();
		try {
			this.socket.setReuseAddress(true);
			this.socket.bind(new InetSocketAddress(port));
		}
		catch (final IOException e) {
			this.socket.close();
			this.watchdog.shutdownNow();
			throw e;
		}
		LanConnection.thread("LAN accept", this::accept);
		this.watchdog.scheduleAtFixedRate(this::checkTimeout, 1, 1, TimeUnit.SECONDS);
	}

	public int port() {
		return this.socket.getLocalPort();
	}

	/** Kept on the hosting device; clients cannot claim the reserved host slot. */
	public String hostKey() {
		return this.hostKey;
	}

	private void accept() {
		while (!this.socket.isClosed()) {
			try {
				final Socket accepted = this.socket.accept();
				synchronized (this) {
					if (this.closed || this.connections.size() >= LanLobby.MAX_PLAYERS + 4) {
						accepted.close();
						continue;
					}
					final Peer peer = new Peer(accepted);
					this.connections.add(peer);
					peer.connection.start();
				}
			}
			catch (final IOException e) {
				if (!this.socket.isClosed()) {
					stop("Server LAN tidak dapat menerima koneksi.");
				}
			}
		}
	}

	private synchronized void receive(final Peer peer, final LanProtocol.Message message) throws IOException {
		if (this.closed) {
			return;
		}
		if (peer.player < 0) {
			if (!"hello".equals(message.type)) {
				throw new IOException("Masuk ke ruang LAN terlebih dahulu.");
			}
			join(peer, message);
			return;
		}
		final LanLobby.Slot slot = this.lobby.slot(peer.player);
		switch (message.type) {
		case "choice":
			requireLobby();
			if (message.race < 0 || message.race > 4 || message.team < 0 || message.team >= LanLobby.MAX_PLAYERS) {
				throw new IOException("Ras atau tim LAN tidak valid.");
			}
			slot.race = message.race;
			slot.team = message.team;
			resetReady();
			broadcastLobby("lobby");
			break;
		case "ready":
			requireLobby();
			if (!this.lobby.mapHash.equals(message.mapHash)) {
				throw new IOException("Peta berbeda dengan host. Gunakan berkas peta yang sama.");
			}
			if (this.lobby.dataChecksum != message.dataChecksum || !this.lobby.graphics.equals(message.graphics)) {
				throw new IOException("Data atau set grafis berbeda dengan host. Samakan data game dan set grafis.");
			}
			peer.verified = true;
			slot.ready = message.ready;
			broadcastLobby("lobby");
			break;
		case "start":
			requireLobby();
			if (!peer.host) {
				throw new IOException("Hanya host yang dapat memulai pertandingan.");
			}
			if (!this.lobby.canStart()) {
				// A join or choice can race the host's tap. Refresh the lobby instead of disconnecting the host.
				broadcastLobby("lobby");
				return;
			}
			this.lobby.started = true;
			this.progress = System.nanoTime();
			broadcastLobby("start");
			break;
		case "loaded":
			if (!this.lobby.started || this.running || peer.loaded || !peer.verified) {
				throw new IOException("Status pemuatan LAN tidak valid.");
			}
			peer.loaded = true;
			peer.initialChecksum = message.checksum;
			if (this.players.values().stream().allMatch(player -> player.loaded)) {
				final int checksum = this.players.values().iterator().next().initialChecksum;
				if (this.players.values().stream().anyMatch(player -> player.initialChecksum != checksum)) {
					stop("Kondisi awal permainan berbeda. Samakan peta, data game, dan versi APK.");
					return;
				}
				this.running = true;
				final LanProtocol.Message first = new LanProtocol.Message("turn");
				first.turn = 0;
				first.orders = new ArrayList<>();
				broadcast(first);
				this.turn = 1;
				this.progress = System.nanoTime();
			}
			break;
		case "input":
			if (!this.running || message.turn != this.turn || this.inputs.containsKey(peer.player)) {
				throw new IOException("Urutan langkah LAN tidak valid.");
			}
			if (!peer.active) {
				return;
			}
			LanCommands.validate(message.commands);
			this.inputs.put(peer.player, message);
			flushTurn();
			break;
		case "retire":
			if (this.running) {
				retire(peer);
			}
			break;
		default:
			throw new IOException("Pesan LAN tidak dikenal.");
		}
	}

	private void join(final Peer peer, final LanProtocol.Message message) throws IOException {
		requireLobby();
		if (message.protocol != LanProtocol.VERSION || !this.lobby.engineVersion.equals(message.version)) {
			throw new IOException("Versi APK berbeda. Pasang APK LAN yang sama pada semua HP.");
		}
		peer.host = this.hostKey.equals(message.hostKey);
		LanLobby.Slot available = null;
		for (int i = peer.host ? 0 : 1; i < this.lobby.slots.size(); i++) {
			final LanLobby.Slot candidate = this.lobby.slots.get(i);
			if (!candidate.occupied() && (!peer.host || i == 0)) {
				available = candidate;
				break;
			}
		}
		if (available == null) {
			throw new IOException("Ruang LAN penuh.");
		}
		String name = message.name == null ? "Pemain" : message.name.replaceAll("[\\p{Cntrl}|]", "").trim();
		if (name.isEmpty()) {
			name = "Pemain";
		}
		available.name = name.substring(0, Math.min(32, name.length()));
		peer.player = available.player;
		this.players.put(peer.player, peer);
		resetReady();
		final LanProtocol.Message welcome = new LanProtocol.Message("welcome");
		welcome.player = peer.player;
		welcome.lobby = this.lobby.copy();
		peer.connection.send(welcome);
		broadcastLobby("lobby");
	}

	private void requireLobby() throws IOException {
		if (this.lobby.started) {
			throw new IOException("Pertandingan sudah dimulai.");
		}
	}

	private void resetReady() {
		for (final LanLobby.Slot slot : this.lobby.slots) {
			slot.ready = false;
		}
	}

	private void flushTurn() {
		final List<Peer> active = new ArrayList<>();
		for (final Peer peer : this.players.values()) {
			if (peer.active) {
				active.add(peer);
				if (!this.inputs.containsKey(peer.player)) {
					return;
				}
			}
		}
		if (active.isEmpty()) {
			return;
		}
		if (this.turn % LanProtocol.CHECKSUM_INTERVAL == 0) {
			final int checksum = this.inputs.get(active.get(0).player).checksum;
			for (final Peer peer : active) {
				if (this.inputs.get(peer.player).checksum != checksum) {
					stop("Simulasi tidak sinkron pada langkah " + this.turn + ". Pertandingan dihentikan.");
					return;
				}
			}
		}
		final LanProtocol.Message batch = new LanProtocol.Message("turn");
		batch.turn = this.turn;
		batch.orders = new ArrayList<>();
		for (final int player : this.departed) {
			batch.orders.add(new LanProtocol.Order(player, new byte[] { CPlayerCommandCodec.LEAVE_GAME }));
		}
		for (final Peer peer : active) {
			batch.orders.add(new LanProtocol.Order(peer.player, this.inputs.get(peer.player).commands));
		}
		this.inputs.clear();
		this.departed.clear();
		this.turn++;
		this.progress = System.nanoTime();
		for (final Peer peer : active) {
			peer.connection.send(batch);
		}
	}

	private void retire(final Peer peer) {
		if (peer.active) {
			peer.active = false;
			this.inputs.remove(peer.player);
			this.departed.add(peer.player);
			flushTurn();
		}
	}

	private synchronized void disconnected(final Peer peer) {
		this.connections.remove(peer);
		if (this.closed || peer.player < 0) {
			return;
		}
		if (peer.host) {
			stop("Host menutup ruang atau koneksi host terputus.");
			return;
		}
		if (this.lobby.started && !this.running) {
			stop("Seorang pemain keluar saat memuat peta. Buat ruang baru untuk bermain lagi.");
			return;
		}
		if (this.running) {
			retire(peer);
		}
		this.players.remove(peer.player);
		if (!this.lobby.started) {
			this.lobby.slot(peer.player).name = "";
			resetReady();
			broadcastLobby("lobby");
		}
	}

	private void broadcastLobby(final String type) {
		final LanProtocol.Message message = new LanProtocol.Message(type);
		message.lobby = this.lobby.copy();
		broadcast(message);
	}

	private void broadcast(final LanProtocol.Message message) {
		for (final Peer peer : new ArrayList<>(this.players.values())) {
			peer.connection.send(message);
		}
	}

	private synchronized void checkTimeout() {
		if (this.closed) {
			return;
		}
		final long now = System.nanoTime();
		for (final Peer peer : new ArrayList<>(this.connections)) {
			if (peer.player < 0 && now - peer.connected > TimeUnit.SECONDS.toNanos(10)) {
				peer.connection.reject("Waktu masuk ruang LAN habis.");
			}
		}
		if (this.lobby.started && now - this.progress > TimeUnit.SECONDS.toNanos(this.running ? 45 : 300)
				&& this.players.values().stream().anyMatch(peer -> peer.active)) {
			stop(this.running ? "Pemain tidak merespons selama 45 detik. Pertandingan dihentikan."
					: "Waktu memuat peta habis. Buat ruang baru dan coba peta yang lebih kecil.");
		}
	}

	private synchronized void stop(final String reason) {
		if (this.closed) {
			return;
		}
		this.closed = true;
		try {
			this.socket.close();
		}
		catch (final IOException ignored) {
		}
		this.watchdog.shutdownNow();
		for (final Peer peer : new ArrayList<>(this.connections)) {
			peer.connection.reject(reason);
		}
	}

	@Override
	public void close() {
		stop("Host menutup ruang LAN.");
	}

	private final class Peer implements LanConnection.Listener {
		private final LanConnection connection;
		private final long connected = System.nanoTime();
		private int player = -1;
		private boolean host;
		private boolean verified;
		private boolean loaded;
		private boolean active = true;
		private int initialChecksum;

		private Peer(final Socket socket) throws IOException {
			this.connection = new LanConnection(socket, this);
		}

		@Override
		public void received(final LanProtocol.Message message) throws IOException {
			receive(this, message);
		}

		@Override
		public void closed(final String reason) {
			disconnected(this);
		}
	}
}
