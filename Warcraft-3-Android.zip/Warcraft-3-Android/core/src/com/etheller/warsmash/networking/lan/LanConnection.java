package com.etheller.warsmash.networking.lan;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

/** Socket I/O never runs on either Android's main thread or the simulation thread. */
final class LanConnection implements AutoCloseable {
	private static final ScheduledExecutorService CLOSER = Executors.newSingleThreadScheduledExecutor(action -> {
		final Thread thread = new Thread(action, "LAN close");
		thread.setDaemon(true);
		return thread;
	});
	interface Listener {
		void received(LanProtocol.Message message) throws IOException;
		void closed(String reason);
	}

	private final Socket socket;
	private final Listener listener;
	private final ArrayBlockingQueue<LanProtocol.Message> outgoing = new ArrayBlockingQueue<>(128);
	private final AtomicBoolean closed = new AtomicBoolean();
	private final AtomicBoolean rejecting = new AtomicBoolean();
	private Thread writer;

	LanConnection(final Socket socket, final Listener listener) throws IOException {
		this.socket = socket;
		this.listener = listener;
		socket.setTcpNoDelay(true);
		socket.setKeepAlive(true);
		socket.setSoTimeout(15000);
	}

	void start() {
		this.writer = thread("LAN send", () -> {
			try {
				final DataOutputStream out = new DataOutputStream(new BufferedOutputStream(this.socket.getOutputStream()));
				while (!this.closed.get()) {
					LanProtocol.Message message = this.outgoing.poll(2, TimeUnit.SECONDS);
					if (message == null) {
						message = new LanProtocol.Message("ping");
					}
					LanProtocol.write(out, message);
					if ("error".equals(message.type)) {
						fail(message.text);
					}
				}
			}
			catch (final IOException | InterruptedException e) {
				fail("Koneksi LAN terputus. Periksa Wi-Fi atau hotspot.");
			}
		});
		thread("LAN receive", () -> {
			try {
				final DataInputStream in = new DataInputStream(new BufferedInputStream(this.socket.getInputStream()));
				while (!this.closed.get()) {
					final LanProtocol.Message message = LanProtocol.read(in);
					if (!"ping".equals(message.type)) {
						try {
							this.listener.received(message);
						}
						catch (final IllegalArgumentException | IOException e) {
							reject(e.getMessage() == null ? "Pesan LAN tidak valid." : e.getMessage());
							return;
						}
					}
				}
			}
			catch (final SocketTimeoutException e) {
				fail("Koneksi LAN tidak merespons. Periksa Wi-Fi atau hotspot.");
			}
			catch (final IOException | RuntimeException e) {
				fail("Koneksi LAN terputus. Periksa Wi-Fi atau hotspot.");
			}
		});
	}

	static Thread thread(final String name, final Runnable action) {
		final Thread thread = new Thread(action, name);
		thread.setDaemon(true);
		thread.start();
		return thread;
	}

	void send(final LanProtocol.Message message) {
		if (!this.closed.get() && !this.rejecting.get() && !this.outgoing.offer(message)) {
			fail("Koneksi LAN terlalu lambat untuk menerima perintah.");
		}
	}

	void reject(final String reason) {
		if (this.closed.get() || !this.rejecting.compareAndSet(false, true)) {
			return;
		}
		final LanProtocol.Message message = new LanProtocol.Message("error");
		message.text = reason;
		this.outgoing.clear();
		this.outgoing.offer(message);
		// A peer that stops reading must not keep a socket and blocked writer alive after the room closes.
		CLOSER.schedule(() -> fail(reason), 1, TimeUnit.SECONDS);
	}

	void fail(final String reason) {
		if (this.closed.compareAndSet(false, true)) {
			try {
				this.socket.close();
			}
			catch (final IOException ignored) {
			}
			if (this.writer != null) {
				this.writer.interrupt();
			}
			this.listener.closed(reason);
		}
	}

	@Override
	public void close() {
		fail("Koneksi LAN ditutup.");
	}
}
