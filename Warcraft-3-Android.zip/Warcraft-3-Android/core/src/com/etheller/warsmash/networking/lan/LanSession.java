package com.etheller.warsmash.networking.lan;

import java.util.UUID;

/** Process-local ownership: a launch ID cannot revive a lost socket after Android kills the process. */
public final class LanSession implements AutoCloseable {
	private static volatile LanSession current;
	public final String id = UUID.randomUUID().toString();
	public final LanClient client;
	public final LanServer server;
	private volatile String localMap;

	public LanSession(final LanClient client, final LanServer server) {
		this.client = client;
		this.server = server;
	}

	public static synchronized void install(final LanSession session) {
		if (current != null && current != session) {
			current.close();
		}
		current = session;
	}

	public static LanSession find(final String id) {
		final LanSession session = current;
		return session != null && session.id.equals(id) ? session : null;
	}

	public String localMap() {
		return this.localMap;
	}

	public void setLocalMap(final String path) {
		this.localMap = path;
	}

	@Override
	public void close() {
		this.client.close();
		if (this.server != null) {
			this.server.close();
		}
		synchronized (LanSession.class) {
			if (current == this) {
				current = null;
			}
		}
	}
}
