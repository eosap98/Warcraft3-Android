package com.etheller.warsmash.networking.lan;

import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerCommandCodec;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerUnitOrderListener;

/** Collects local input for the next shared turn. Single-player save, pause and cheats cannot enter LAN turns. */
public final class LanCommands implements CPlayerUnitOrderListener {
	private final CPlayerCommandCodec.Encoder encoder = new CPlayerCommandCodec.Encoder();
	private final boolean validating;

	public LanCommands() {
		this(false);
	}

	private LanCommands(final boolean validating) {
		this.validating = validating;
	}

	public byte[] take() {
		return this.encoder.take();
	}

	static void validate(final byte[] commands) {
		if (commands == null || commands.length > LanProtocol.MAX_COMMAND_BYTES) {
			throw new IllegalArgumentException("Perintah LAN terlalu besar.");
		}
		CPlayerCommandCodec.decode(commands, new LanCommands(true));
	}

	private void singlePlayerOnly() {
		if (this.validating) {
			throw new IllegalArgumentException("Perintah mode pemain tunggal tidak tersedia dalam LAN.");
		}
	}

	@Override
	public void saveGame(final String name) {
		singlePlayerOnly();
	}

	@Override
	public void cheat(final String cheat) {
		singlePlayerOnly();
	}

	@Override
	public void setGamePaused(final boolean paused) {
		singlePlayerOnly();
	}

	@Override
	public void issueTargetOrder(final int unit, final int ability, final int order, final int target, final boolean queue) {
		this.encoder.issueTargetOrder(unit, ability, order, target, queue);
	}

	@Override
	public void issuePointOrder(final int unit, final int ability, final int order, final float x, final float y, final boolean queue) {
		this.encoder.issuePointOrder(unit, ability, order, x, y, queue);
	}

	@Override
	public void issueGroupPointOrder(final int[] units, final int[] abilities, final int order, final float[] xs, final float[] ys, final boolean queue) {
		this.encoder.issueGroupPointOrder(units, abilities, order, xs, ys, queue);
	}

	@Override
	public void issueDropItemAtPointOrder(final int unit, final int ability, final int order, final int target, final float x, final float y, final boolean queue) {
		this.encoder.issueDropItemAtPointOrder(unit, ability, order, target, x, y, queue);
	}

	@Override
	public void issueDropItemAtTargetOrder(final int unit, final int ability, final int order, final int item, final int hero, final boolean queue) {
		this.encoder.issueDropItemAtTargetOrder(unit, ability, order, item, hero, queue);
	}

	@Override
	public void issueImmediateOrder(final int unit, final int ability, final int order, final boolean queue) {
		this.encoder.issueImmediateOrder(unit, ability, order, queue);
	}

	@Override
	public void unitCancelTrainingItem(final int unit, final int index) {
		this.encoder.unitCancelTrainingItem(unit, index);
	}

	@Override
	public void issueGuiPlayerEvent(final int event) {
		this.encoder.issueGuiPlayerEvent(event);
	}

	@Override
	public void selectUnits(final int[] deselected, final int[] selected) {
		this.encoder.selectUnits(deselected, selected);
	}

	@Override
	public void chatMessage(final int recipient, final int player, final String message) {
		this.encoder.chatMessage(recipient, player, message);
	}

	@Override
	public void clickDialogButton(final int dialog, final int button) {
		this.encoder.clickDialogButton(dialog, button);
	}

	@Override
	public void setAlliance(final int player, final int type, final boolean value) {
		this.encoder.setAlliance(player, type, value);
	}

	@Override
	public void transferResources(final int player, final int gold, final int lumber) {
		this.encoder.transferResources(player, gold, lumber);
	}

	@Override
	public void fireGameEvent(final int event) {
		this.encoder.fireGameEvent(event);
	}

	@Override
	public void leaveGame() {
		this.encoder.leaveGame();
	}

	@Override
	public void minimapSignal(final float x, final float y) {
		this.encoder.minimapSignal(x, y);
	}

	@Override
	public void trackableEvent(final int trackable, final boolean hit) {
		this.encoder.trackableEvent(trackable, hit);
	}
}
