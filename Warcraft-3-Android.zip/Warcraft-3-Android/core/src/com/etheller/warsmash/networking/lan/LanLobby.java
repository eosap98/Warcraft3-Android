package com.etheller.warsmash.networking.lan;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** The host's complete, shared setup. Slot numbers are map player IDs, not list positions. */
public final class LanLobby {
	public static final int MAX_PLAYERS = 12;
	public String engineVersion;
	public String mapFile;
	public String mapName;
	public String mapHash;
	public int dataChecksum;
	public String graphics;
	public int seed;
	public boolean started;
	public List<Slot> slots = new ArrayList<>();

	public static final class Slot {
		public int player;
		public int race;
		public int team;
		public String name = "";
		public boolean ready;

		public Slot() {
		}

		public Slot(final int player, final int race, final int team) {
			this.player = player;
			this.race = race;
			this.team = team;
		}

		public boolean occupied() {
			return this.name != null && !this.name.isEmpty();
		}
	}

	public Slot slot(final int player) {
		for (final Slot slot : this.slots) {
			if (slot.player == player) {
				return slot;
			}
		}
		return null;
	}

	public int playerCount() {
		int count = 0;
		for (final Slot slot : this.slots) {
			if (slot.occupied()) {
				count++;
			}
		}
		return count;
	}

	public boolean canStart() {
		final Set<Integer> teams = new HashSet<>();
		if (this.started || playerCount() < 2) {
			return false;
		}
		for (final Slot slot : this.slots) {
			if (slot.occupied()) {
				if (!slot.ready) {
					return false;
				}
				teams.add(slot.team);
			}
		}
		return teams.size() > 1;
	}

	public void validate() {
		if (this.engineVersion == null || this.engineVersion.length() > 64 || this.mapName == null
				|| this.mapName.length() > 512 || this.mapFile == null || this.mapFile.length() > 512
				|| this.mapHash == null || !this.mapHash.matches("[0-9a-f]{64}") || this.graphics == null
				|| this.graphics.length() > 32 || this.slots == null || this.slots.size() < 2
				|| this.slots.size() > MAX_PLAYERS) {
			throw new IllegalArgumentException("Pengaturan ruang LAN tidak valid.");
		}
		final Set<Integer> players = new HashSet<>();
		for (final Slot slot : this.slots) {
			if (slot == null || slot.player < 0 || slot.player >= 24 || !players.add(slot.player)
					|| slot.race < 0 || slot.race > 4 || slot.team < 0 || slot.team >= MAX_PLAYERS
					|| slot.name == null || slot.name.length() > 32) {
				throw new IllegalArgumentException("Slot pemain LAN tidak valid.");
			}
		}
	}

	public LanLobby copy() {
		final LanLobby copy = new LanLobby();
		copy.engineVersion = this.engineVersion;
		copy.mapFile = this.mapFile;
		copy.mapName = this.mapName;
		copy.mapHash = this.mapHash;
		copy.dataChecksum = this.dataChecksum;
		copy.graphics = this.graphics;
		copy.seed = this.seed;
		copy.started = this.started;
		for (final Slot slot : this.slots) {
			final Slot next = new Slot(slot.player, slot.race, slot.team);
			next.name = slot.name;
			next.ready = slot.ready;
			copy.slots.add(next);
		}
		return copy;
	}
}
