package com.etheller.warsmash.networking.lan;

import java.util.HashMap;
import java.util.Map;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

import com.etheller.warsmash.networking.GameTurnManager;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.CSimulation;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.SimulationChecksum;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerCommandCodec;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerCommandRecorder;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerUnitOrderListener;

/** Applies a complete host-authorized batch exactly once, immediately before its simulation step. */
public final class LanTurnManager implements GameTurnManager {
	private final LanClient client;
	private final IntSupplier tick;
	private final IntSupplier checksum;
	private final IntFunction<CPlayerUnitOrderListener> executor;
	private final Map<Integer, CPlayerUnitOrderListener> executors = new HashMap<>();
	private final LanCommands commands = new LanCommands();
	private int prepared = -1;
	private boolean loaded;

	public LanTurnManager(final LanClient client, final CSimulation simulation) {
		this(client, simulation::getGameTurnTick, () -> SimulationChecksum.compute(simulation),
				player -> new CPlayerCommandRecorder(simulation, player,
						new LanPlayerOrderExecutor(simulation, player)));
	}

	LanTurnManager(final LanClient client, final IntSupplier tick, final IntSupplier checksum,
			final IntFunction<CPlayerUnitOrderListener> executor) {
		this.client = client;
		this.tick = tick;
		this.checksum = checksum;
		this.executor = executor;
	}

	public CPlayerUnitOrderListener commands() {
		return this.commands;
	}

	@Override
	public int getLatestCompletedTurn() {
		if (this.client.error() != null || this.client.isFinished()) {
			return Integer.MIN_VALUE;
		}
		if (!this.loaded) {
			// The first simulation poll is after the map screen has built its UI and run the map's main script.
			this.loaded = true;
			this.client.loaded(this.checksum.getAsInt());
		}
		final int tick = this.tick.getAsInt();
		if (this.prepared == tick) {
			return tick;
		}
		final LanProtocol.Message batch = this.client.pollTurn();
		if (batch == null) {
			return this.prepared;
		}
		if (batch.turn != tick) {
			this.client.abort("Langkah simulasi LAN berbeda dengan host.");
			return Integer.MIN_VALUE;
		}
		for (final LanProtocol.Order order : batch.orders) {
			CPlayerCommandCodec.decode(order.commands, this.executors.computeIfAbsent(order.player, this.executor::apply));
		}
		this.prepared = tick;
		return tick;
	}

	@Override
	public void turnCompleted(final int gameTurnTick) {
		if (this.client.isFinished()) {
			return;
		}
		if (gameTurnTick != this.prepared + 1) {
			this.client.abort("Langkah simulasi LAN terlewat.");
			return;
		}
		this.client.input(gameTurnTick, this.commands.take(), gameTurnTick % LanProtocol.CHECKSUM_INTERVAL == 0
				? this.checksum.getAsInt() : 0);
	}

	@Override
	public void framesSkipped(final float skippedCount) {
		// The TCP connection keeps itself alive while this device waits for another player.
	}

	@Override
	public boolean isNetworkGame() {
		return true;
	}

	@Override
	public boolean allowsUserPause() {
		return false;
	}

	@Override
	public void gameEnded() {
		this.client.retire();
	}

	@Override
	public void close() {
		this.client.close();
	}
}
