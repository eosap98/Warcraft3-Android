package com.etheller.warsmash.networking;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.IntIntMap;
import com.etheller.warsmash.util.Log;
import com.etheller.warsmash.util.WarsmashConstants;
import com.etheller.warsmash.viewer5.handlers.w3x.War3MapViewer;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerCommandCodec;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerCommandRecorder;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerUnitOrderExecutor;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CPlayerUnitOrderListener;

import net.warsmash.networking.udp.OrderedUdpClient;

public class WarsmashClient implements ServerToClientListener, GameTurnManager {
	private final OrderedUdpClient udpClient;
	private final War3MapViewer game;
	private final Map<Integer, CPlayerUnitOrderListener> indexToExecutor = new HashMap<>();
	private int latestCompletedTurn = -1;
	private int latestLocallyRequestedTurn = -1;
	private final WarsmashClientWriter writer;
	private final Queue<QueuedMessage> queuedMessages = new ArrayDeque<>();
	private final IntIntMap serverSlotToMapSlot;

	public WarsmashClient(final InetAddress serverAddress, final int udpPort, final War3MapViewer game,
			final long sessionToken, final IntIntMap serverSlotToMapSlot) throws UnknownHostException, IOException {
		this.udpClient = new OrderedUdpClient(serverAddress, udpPort, new WarsmashClientParser(this));
		this.game = game;
		this.writer = new WarsmashClientWriter(this.udpClient, sessionToken);
		this.serverSlotToMapSlot = serverSlotToMapSlot;
	}

	private CPlayerUnitOrderListener getExecutor(final int serverPlayerIndex) {
		final int mapPlayerIndex = this.serverSlotToMapSlot.get(serverPlayerIndex, -1);
		CPlayerUnitOrderListener executor = this.indexToExecutor.get(serverPlayerIndex);
		if (executor == null) {
			executor = new CPlayerCommandRecorder(this.game.simulation, mapPlayerIndex,
					new CPlayerUnitOrderExecutor(this.game.simulation, mapPlayerIndex));
			this.indexToExecutor.put(serverPlayerIndex, executor);
		}
		return executor;
	}

	public void startThread() {
		new Thread(this.udpClient).start();
	}

	@Override
	public void acceptJoin(final int playerIndex) {
		Log.warn("acceptJoin " + playerIndex);
		this.game.setLocalPlayerServerSlot(playerIndex);
	}

	@Override
	public void issueTargetOrder(final int playerIndex, final int unitHandleId, final int abilityHandleId,
			final int orderId, final int targetHandleId, final boolean queue) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							executor.issueTargetOrder(unitHandleId, abilityHandleId, orderId, targetHandleId, queue);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					executor.issueTargetOrder(unitHandleId, abilityHandleId, orderId, targetHandleId, queue);
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});
	}

	@Override
	public void issuePointOrder(final int playerIndex, final int unitHandleId, final int abilityHandleId,
			final int orderId, final float x, final float y, final boolean queue) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							executor.issuePointOrder(unitHandleId, abilityHandleId, orderId, x, y, queue);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					executor.issuePointOrder(unitHandleId, abilityHandleId, orderId, x, y, queue);
					;
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});

	}

	@Override
	public void issueDropItemAtPointOrder(final int playerIndex, final int unitHandleId, final int abilityHandleId,
			final int orderId, final int targetHandleId, final float x, final float y, final boolean queue) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							executor.issueDropItemAtPointOrder(unitHandleId, abilityHandleId, orderId, targetHandleId,
									x, y, queue);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					executor.issueDropItemAtPointOrder(unitHandleId, abilityHandleId, orderId, targetHandleId, x, y,
							queue);
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});
	}

	@Override
	public void issueDropItemAtTargetOrder(final int playerIndex, final int unitHandleId, final int abilityHandleId,
			final int orderId, final int targetHandleId, final int targetHeroHandleId, final boolean queue) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							executor.issueDropItemAtTargetOrder(unitHandleId, abilityHandleId, orderId, targetHandleId,
									targetHeroHandleId, queue);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					executor.issueDropItemAtTargetOrder(unitHandleId, abilityHandleId, orderId, targetHandleId,
							targetHeroHandleId, queue);
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});
	}

	@Override
	public void issueImmediateOrder(final int playerIndex, final int unitHandleId, final int abilityHandleId,
			final int orderId, final boolean queue) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							executor.issueImmediateOrder(unitHandleId, abilityHandleId, orderId, queue);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					executor.issueImmediateOrder(unitHandleId, abilityHandleId, orderId, queue);
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});
	}

	@Override
	public void unitCancelTrainingItem(final int playerIndex, final int unitHandleId, final int cancelIndex) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							executor.unitCancelTrainingItem(unitHandleId, cancelIndex);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					executor.unitCancelTrainingItem(unitHandleId, cancelIndex);
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});
	}

	@Override
	public void issueGuiPlayerEvent(final int playerIndex, final int eventId) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							executor.issueGuiPlayerEvent(eventId);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					executor.issueGuiPlayerEvent(eventId);
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});
	}

	@Override
	public void issuePlayerCommand(final int playerIndex, final byte[] command) {
		final CPlayerUnitOrderListener executor = getExecutor(playerIndex);
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				final int currentServerTurnInProgress = WarsmashClient.this.latestCompletedTurn + 1;
				if (currentServerTurnInProgress > WarsmashClient.this.latestLocallyRequestedTurn) {
					WarsmashClient.this.queuedMessages.add(new QueuedMessage(currentServerTurnInProgress) {
						@Override
						public void run() {
							CPlayerCommandCodec.decode(command, executor);
						}
					});
				}
				else if (currentServerTurnInProgress == WarsmashClient.this.latestLocallyRequestedTurn) {
					CPlayerCommandCodec.decode(command, executor);
				}
				else {
					Log.warn("Turn tick system mismatch: " + currentServerTurnInProgress + " < "
							+ WarsmashClient.this.latestLocallyRequestedTurn);
				}
			}
		});
	}

	@Override
	public void finishedTurn(final int gameTurnTick) {
		if (WarsmashConstants.VERBOSE_LOGGING) {
			Log.info("finishedTurn " + gameTurnTick);
		}
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				WarsmashClient.this.latestCompletedTurn = gameTurnTick;
			}
		});
	}

	@Override
	public void turnCompleted(final int gameTurnTick) {
		if (WarsmashConstants.VERBOSE_LOGGING) {
			Log.info("turnCompleted " + gameTurnTick);
		}
		this.writer.finishedTurn(gameTurnTick);
		this.writer.send();
		this.latestLocallyRequestedTurn = gameTurnTick;
		while (!this.queuedMessages.isEmpty()
				&& (this.queuedMessages.peek().messageTurnTick == this.latestLocallyRequestedTurn)) {
			this.queuedMessages.poll().run();
		}
		if (!this.queuedMessages.isEmpty()) {
			Log.info("stopped with " + this.queuedMessages.peek().messageTurnTick + " != "
					+ this.latestLocallyRequestedTurn);
		}
	}

	@Override
	public void startGame() {
		Gdx.app.postRunnable(new Runnable() {
			@Override
			public void run() {
				WarsmashClient.this.game.setGameTurnManager(WarsmashClient.this);
			}
		});
	}

	@Override
	public void framesSkipped(final float skippedCount) {
		this.writer.framesSkipped((int) skippedCount);
		this.writer.send();
	}

	@Override
	public void heartbeat() {
		// Not doing anything here at the moment. The act of the server sending us that
		// packet
		// will let the middle layer UDP system know to re-request any lost packets
		// based
		// on the heartbeat seq no. But at app layer, here, we can ignore it.
		Log.info("got heartbeat() from server");
	}

	@Override
	public int getLatestCompletedTurn() {
		return this.latestCompletedTurn;
	}

	public WarsmashClientWriter getWriter() {
		return this.writer;
	}

	@Override
	public boolean isNetworkGame() {
		return true;
	}

	private static abstract class QueuedMessage implements Runnable {
		private final int messageTurnTick;

		public QueuedMessage(final int messageTurnTick) {
			this.messageTurnTick = messageTurnTick;
		}

		public final int getMessageTurnTick() {
			return this.messageTurnTick;
		}

		@Override
		public abstract void run();
	}
}
