package com.etheller.warsmash.networking.lan;

import java.util.HashSet;
import java.util.Set;

import com.etheller.warsmash.launcher.LauncherSlot;
import com.etheller.warsmash.util.WarsmashConstants;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.config.CBasePlayer;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.config.War3MapConfig;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CMapControl;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CMapFlag;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.players.CMapPlacement;
import com.etheller.warsmash.viewer5.handlers.w3x.simulation.trigger.enumtypes.CPlayerSlotState;

/** Applies the same lobby on every device, without changing other players into local or computer slots. */
public final class LanGameSetup {
	public static void apply(final War3MapConfig config, final LanLobby lobby) {
		lobby.validate();
		for (int i = 0; i < WarsmashConstants.MAX_PLAYERS - 4; i++) {
			final CBasePlayer player = config.getPlayer(i);
			player.setController(CMapControl.NONE);
			player.setSlotState(CPlayerSlotState.EMPTY);
			player.setAIDifficulty(null);
		}
		final Set<Integer> teams = new HashSet<>();
		for (int i = 0; i < lobby.slots.size(); i++) {
			final LanLobby.Slot slot = lobby.slots.get(i);
			if (!slot.occupied()) {
				continue;
			}
			if (slot.player >= WarsmashConstants.MAX_PLAYERS - 4) {
				throw new IllegalArgumentException("Slot LAN di luar batas peta.");
			}
			final CBasePlayer player = config.getPlayer(slot.player);
			player.setController(CMapControl.USER);
			player.setSlotState(CPlayerSlotState.PLAYING);
			player.setName(slot.name);
			player.setTeam(slot.team);
			player.setColor(i);
			player.setRacePref(slot.race == 0 ? WarsmashConstants.RACE_MANAGER.getRandomRacePreference()
					: WarsmashConstants.RACE_MANAGER.getRacePreferenceForRace(WarsmashConstants.RACE_MANAGER.getRace(slot.race)));
			teams.add(slot.team);
		}
		config.setPlayerCount(lobby.playerCount());
		config.setTeamCount(teams.size());
		config.setLobbyTeams(true);
		config.setPlacement(CMapPlacement.TEAMS_TOGETHER);
		config.setMapFlag(CMapFlag.MAP_LOCK_ALLIANCE_CHANGES, true);
		config.setMapFlag(CMapFlag.MAP_SHARED_ADVANCED_CONTROL, false);
		config.setMapFlag(CMapFlag.MAP_RANDOM_RACES, false);
		config.setMapFlag(CMapFlag.MAP_RANDOM_HERO, false);
		config.setMapFlag(CMapFlag.MAP_OBSERVERS, false);
		config.setMapFlag(CMapFlag.MAP_OBSERVERS_ON_DEATH, false);
	}

	/** Only loading art depends on the local player: list that slot first for the existing loading-screen contract. */
	public static String loadingSlots(final LanLobby lobby, final int localPlayer) {
		final StringBuilder slots = new StringBuilder();
		for (int pass = 0; pass < 2; pass++) {
			for (int i = 0; i < lobby.slots.size(); i++) {
				final LanLobby.Slot slot = lobby.slots.get(i);
				if ((slot.player == localPlayer) == (pass == 0)) {
					new LauncherSlot(slot.player, slot.occupied() ? "USER" : "CLOSED", slot.race, slot.team, i).appendTo(slots);
				}
			}
		}
		return slots.toString();
	}

	private LanGameSetup() {
	}
}
